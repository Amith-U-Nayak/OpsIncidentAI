import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Runbooks.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1aa83cf1"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=1aa83cf1"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import api from "/src/api/axios.js";
const Runbooks = () => {
  _s();
  const [runbooks, setRunbooks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState({ title: "", tags: "" });
  const [content, setContent] = useState("");
  useEffect(() => {
    fetchRunbooks();
  }, []);
  const fetchRunbooks = async () => {
    try {
      const { data } = await api.get("/runbooks");
      setRunbooks(data.data);
    } catch (err) {
      setError("Failed to load runbooks.");
    } finally {
      setLoading(false);
    }
  };
  const handleUpload = async (e) => {
    e.preventDefault();
    setUploading(true);
    setError("");
    try {
      const tagsArray = form.tags.split(",").map((tag) => tag.trim()).filter((tag) => tag);
      await api.post("/runbooks", {
        title: form.title,
        content,
        tags: tagsArray
      });
      setForm({ title: "", tags: "" });
      setContent("");
      fetchRunbooks();
    } catch (err) {
      setError(err.response?.data?.error || "Failed to upload runbook");
    } finally {
      setUploading(false);
    }
  };
  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this runbook?")) return;
    try {
      await api.delete(`/runbooks/${id}`);
      setRunbooks(runbooks.filter((r) => r._id !== id));
    } catch (err) {
      alert("Failed to delete runbook");
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "lg:col-span-1 space-y-6", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-white", children: "Knowledge Base" }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx",
          lineNumber: 88,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-slate-400 text-sm", children: "Upload runbooks to train the AI" }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx",
          lineNumber: 89,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx",
        lineNumber: 87,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleUpload, className: "bg-slate-800 rounded-xl p-6 border border-slate-700 space-y-4", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-white font-medium mb-4", children: "Add New Runbook" }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx",
          lineNumber: 93,
          columnNumber: 11
        }, this),
        error && /* @__PURE__ */ jsxDEV("div", { className: "text-red-400 text-sm bg-red-500/10 p-3 rounded", children: error }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx",
          lineNumber: 95,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-slate-400 text-sm mb-1 block", children: "Title" }, void 0, false, {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx",
            lineNumber: 98,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              required: true,
              value: form.title,
              onChange: (e) => setForm({ ...form, title: e.target.value }),
              className: "w-full bg-slate-900 border border-slate-600 text-white rounded-lg px-4 py-2 text-sm focus:outline-none focus:border-indigo-500",
              placeholder: "e.g., Fix Node.js OOM Crash"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx",
              lineNumber: 99,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx",
          lineNumber: 97,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-slate-400 text-sm mb-1 block", children: "Content / Steps" }, void 0, false, {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx",
            lineNumber: 110,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "textarea",
            {
              required: true,
              rows: "6",
              value: content,
              onChange: (e) => setContent(e.target.value),
              className: "w-full bg-slate-900 border border-slate-600 text-white rounded-lg px-4 py-2 text-sm focus:outline-none focus:border-indigo-500",
              placeholder: "1. SSH into server...\n2. Restart PM2...\n3. Check logs..."
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx",
              lineNumber: 111,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx",
          lineNumber: 109,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-slate-400 text-sm mb-1 block", children: "Tags (comma separated)" }, void 0, false, {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx",
            lineNumber: 122,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              value: form.tags,
              onChange: (e) => setForm({ ...form, tags: e.target.value }),
              className: "w-full bg-slate-900 border border-slate-600 text-white rounded-lg px-4 py-2 text-sm focus:outline-none focus:border-indigo-500",
              placeholder: "nodejs, memory, crash"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx",
              lineNumber: 123,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx",
          lineNumber: 121,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "submit",
            disabled: uploading,
            className: "w-full bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white py-2.5 rounded-lg font-medium transition-colors text-sm",
            children: uploading ? "Embedding and Saving..." : "Upload & Train AI"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx",
            lineNumber: 132,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx",
        lineNumber: 92,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx",
      lineNumber: 86,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "lg:col-span-2", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-slate-800 rounded-xl p-6 border border-slate-700 min-h-full", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-white font-medium mb-6", children: [
        "Active Runbooks (",
        runbooks.length,
        ")"
      ] }, void 0, true, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx",
        lineNumber: 145,
        columnNumber: 11
      }, this),
      loading ? /* @__PURE__ */ jsxDEV("div", { className: "text-indigo-400 animate-pulse text-sm", children: "Loading database..." }, void 0, false, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx",
        lineNumber: 148,
        columnNumber: 11
      }, this) : runbooks.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "text-slate-500 text-center py-12", children: "No runbooks found. Add one to power up the AI's Tier 1 matching." }, void 0, false, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx",
        lineNumber: 150,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: runbooks.map(
        (runbook) => /* @__PURE__ */ jsxDEV("div", { className: "bg-slate-900 rounded-lg p-5 border border-slate-700", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-start mb-2", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-indigo-400 font-medium", children: runbook.title }, void 0, false, {
              fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx",
              lineNumber: 158,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => handleDelete(runbook._id),
                className: "text-slate-500 hover:text-red-400 text-sm transition-colors",
                children: "Delete"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx",
                lineNumber: 159,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx",
            lineNumber: 157,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-slate-300 text-sm mb-3 line-clamp-2", children: runbook.content }, void 0, false, {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx",
            lineNumber: 166,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: runbook.tags.map(
            (tag) => /* @__PURE__ */ jsxDEV("span", { className: "bg-slate-800 text-slate-400 px-2 py-0.5 rounded text-xs border border-slate-700", children: [
              "#",
              tag
            ] }, tag, true, {
              fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx",
              lineNumber: 169,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx",
            lineNumber: 167,
            columnNumber: 19
          }, this)
        ] }, runbook._id, true, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx",
          lineNumber: 156,
          columnNumber: 13
        }, this)
      ) }, void 0, false, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx",
        lineNumber: 154,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx",
      lineNumber: 144,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx",
      lineNumber: 143,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx",
    lineNumber: 84,
    columnNumber: 5
  }, this);
};
_s(Runbooks, "SOgEvaQe0XMDXJ8GhnHGCqkY8K4=");
_c = Runbooks;
export default Runbooks;
var _c;
$RefreshReg$(_c, "Runbooks");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Runbooks.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0VVOzs7Ozs7Ozs7Ozs7Ozs7OztBQXBFVixTQUFTQSxVQUFVQyxpQkFBaUI7QUFDcEMsT0FBT0MsU0FBUztBQUVoQixNQUFNQyxXQUFXQSxNQUFNO0FBQUFDLEtBQUE7QUFDckIsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUlOLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNPLFNBQVNDLFVBQVUsSUFBSVIsU0FBUyxJQUFJO0FBQzNDLFFBQU0sQ0FBQ1MsV0FBV0MsWUFBWSxJQUFJVixTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDVyxPQUFPQyxRQUFRLElBQUlaLFNBQVMsRUFBRTtBQUVyQyxRQUFNLENBQUNhLE1BQU1DLE9BQU8sSUFBSWQsU0FBUyxFQUFFZSxPQUFPLElBQUlDLE1BQU0sR0FBRyxDQUFDO0FBQ3hELFFBQU0sQ0FBQ0MsU0FBU0MsVUFBVSxJQUFJbEIsU0FBUyxFQUFFO0FBRXpDQyxZQUFVLE1BQU07QUFDZGtCLGtCQUFjO0FBQUEsRUFDaEIsR0FBRyxFQUFFO0FBRUwsUUFBTUEsZ0JBQWdCLFlBQVk7QUFDaEMsUUFBSTtBQUNGLFlBQU0sRUFBRUMsS0FBSyxJQUFJLE1BQU1sQixJQUFJbUIsSUFBSSxXQUFXO0FBQzFDZixrQkFBWWMsS0FBS0EsSUFBSTtBQUFBLElBQ3ZCLFNBQVNFLEtBQUs7QUFDWlYsZUFBUywwQkFBMEI7QUFBQSxJQUNyQyxVQUFDO0FBQ0NKLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNZSxlQUFlLE9BQU9DLE1BQU07QUFDaENBLE1BQUVDLGVBQWU7QUFDakJmLGlCQUFhLElBQUk7QUFDakJFLGFBQVMsRUFBRTtBQUVYLFFBQUk7QUFFRixZQUFNYyxZQUFZYixLQUFLRyxLQUFLVyxNQUFNLEdBQUcsRUFBRUMsSUFBSSxDQUFBQyxRQUFPQSxJQUFJQyxLQUFLLENBQUMsRUFBRUMsT0FBTyxDQUFBRixRQUFPQSxHQUFHO0FBRS9FLFlBQU0zQixJQUFJOEIsS0FBSyxhQUFhO0FBQUEsUUFDMUJqQixPQUFPRixLQUFLRTtBQUFBQSxRQUNaRTtBQUFBQSxRQUNBRCxNQUFNVTtBQUFBQSxNQUNSLENBQUM7QUFHRFosY0FBUSxFQUFFQyxPQUFPLElBQUlDLE1BQU0sR0FBRyxDQUFDO0FBQy9CRSxpQkFBVyxFQUFFO0FBQ2JDLG9CQUFjO0FBQUEsSUFDaEIsU0FBU0csS0FBSztBQUNaVixlQUFTVSxJQUFJVyxVQUFVYixNQUFNVCxTQUFTLDBCQUEwQjtBQUFBLElBQ2xFLFVBQUM7QUFDQ0QsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUVBLFFBQU13QixlQUFlLE9BQU9DLE9BQU87QUFDakMsUUFBSSxDQUFDQyxPQUFPQyxRQUFRLCtDQUErQyxFQUFHO0FBQ3RFLFFBQUk7QUFDRixZQUFNbkMsSUFBSW9DLE9BQU8sYUFBYUgsRUFBRSxFQUFFO0FBQ2xDN0Isa0JBQVlELFNBQVMwQixPQUFPLENBQUFRLE1BQUtBLEVBQUVDLFFBQVFMLEVBQUUsQ0FBQztBQUFBLElBQ2hELFNBQVNiLEtBQUs7QUFDWm1CLFlBQU0sMEJBQTBCO0FBQUEsSUFDbEM7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsMkRBRWI7QUFBQSwyQkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSw2QkFBQyxTQUNDO0FBQUEsK0JBQUMsUUFBRyxXQUFVLGlDQUFnQyw4QkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RDtBQUFBLFFBQzVELHVCQUFDLE9BQUUsV0FBVSwwQkFBeUIsK0NBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUU7QUFBQSxXQUZ2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUVBLHVCQUFDLFVBQUssVUFBVWxCLGNBQWMsV0FBVSxpRUFDdEM7QUFBQSwrQkFBQyxRQUFHLFdBQVUsK0JBQThCLCtCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJEO0FBQUEsUUFFMURaLFNBQVMsdUJBQUMsU0FBSSxXQUFVLGtEQUFrREEsbUJBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUU7QUFBQSxRQUVqRix1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLHFDQUFvQyxxQkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEQ7QUFBQSxVQUMxRDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0w7QUFBQSxjQUNBLE9BQU9FLEtBQUtFO0FBQUFBLGNBQ1osVUFBVSxDQUFDUyxNQUFNVixRQUFRLEVBQUUsR0FBR0QsTUFBTUUsT0FBT1MsRUFBRWtCLE9BQU9DLE1BQU0sQ0FBQztBQUFBLGNBQzNELFdBQVU7QUFBQSxjQUNWLGFBQVk7QUFBQTtBQUFBLFlBTmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTTJDO0FBQUEsYUFSN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsUUFFQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLHFDQUFvQywrQkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0U7QUFBQSxVQUNwRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0M7QUFBQSxjQUNBLE1BQUs7QUFBQSxjQUNMLE9BQU8xQjtBQUFBQSxjQUNQLFVBQVUsQ0FBQ08sTUFBTU4sV0FBV00sRUFBRWtCLE9BQU9DLEtBQUs7QUFBQSxjQUMxQyxXQUFVO0FBQUEsY0FDVixhQUFZO0FBQUE7QUFBQSxZQU5kO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1nRjtBQUFBLGFBUmxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBRUEsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxxQ0FBb0Msc0NBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJFO0FBQUEsVUFDM0U7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE9BQU85QixLQUFLRztBQUFBQSxjQUNaLFVBQVUsQ0FBQ1EsTUFBTVYsUUFBUSxFQUFFLEdBQUdELE1BQU1HLE1BQU1RLEVBQUVrQixPQUFPQyxNQUFNLENBQUM7QUFBQSxjQUMxRCxXQUFVO0FBQUEsY0FDVixhQUFZO0FBQUE7QUFBQSxZQUxkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtxQztBQUFBLGFBUHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFFBRUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFVBQVVsQztBQUFBQSxZQUNWLFdBQVU7QUFBQSxZQUVUQSxzQkFBWSw0QkFBNEI7QUFBQTtBQUFBLFVBTDNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsV0E5Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQStDQTtBQUFBLFNBckRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzREE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxpQkFDYixpQ0FBQyxTQUFJLFdBQVUsa0VBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsK0JBQThCO0FBQUE7QUFBQSxRQUFrQkosU0FBU3VDO0FBQUFBLFFBQU87QUFBQSxXQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStFO0FBQUEsTUFFOUVyQyxVQUNDLHVCQUFDLFNBQUksV0FBVSx5Q0FBd0MsbUNBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEUsSUFDeEVGLFNBQVN1QyxXQUFXLElBQ3RCLHVCQUFDLFNBQUksV0FBVSxvQ0FBa0MsZ0ZBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNadkMsbUJBQVN1QjtBQUFBQSxRQUFJLENBQUNpQixZQUNiLHVCQUFDLFNBQXNCLFdBQVUsdURBQy9CO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLCtCQUErQkEsa0JBQVE5QixTQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRDtBQUFBLFlBQzNEO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNbUIsYUFBYVcsUUFBUUwsR0FBRztBQUFBLGdCQUN2QyxXQUFVO0FBQUEsZ0JBQTZEO0FBQUE7QUFBQSxjQUZ6RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLGVBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLDRDQUE0Q0ssa0JBQVE1QixXQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RTtBQUFBLFVBQ3pFLHVCQUFDLFNBQUksV0FBVSxjQUNaNEIsa0JBQVE3QixLQUFLWTtBQUFBQSxZQUFJLENBQUFDLFFBQ2hCLHVCQUFDLFVBQWUsV0FBVSxtRkFBaUY7QUFBQTtBQUFBLGNBQ3ZHQTtBQUFBQSxpQkFET0EsS0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsVUFDRCxLQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUE7QUFBQSxhQWpCUWdCLFFBQVFMLEtBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQkE7QUFBQSxNQUNELEtBckJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzQkE7QUFBQSxTQWhDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0NBLEtBbkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQ0E7QUFBQSxPQS9GRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZ0dBO0FBRUo7QUFBRXBDLEdBL0pJRCxVQUFRO0FBQUEsS0FBUkE7QUFpS04sZUFBZUE7QUFBUyxJQUFBMkM7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJhcGkiLCJSdW5ib29rcyIsIl9zIiwicnVuYm9va3MiLCJzZXRSdW5ib29rcyIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwidXBsb2FkaW5nIiwic2V0VXBsb2FkaW5nIiwiZXJyb3IiLCJzZXRFcnJvciIsImZvcm0iLCJzZXRGb3JtIiwidGl0bGUiLCJ0YWdzIiwiY29udGVudCIsInNldENvbnRlbnQiLCJmZXRjaFJ1bmJvb2tzIiwiZGF0YSIsImdldCIsImVyciIsImhhbmRsZVVwbG9hZCIsImUiLCJwcmV2ZW50RGVmYXVsdCIsInRhZ3NBcnJheSIsInNwbGl0IiwibWFwIiwidGFnIiwidHJpbSIsImZpbHRlciIsInBvc3QiLCJyZXNwb25zZSIsImhhbmRsZURlbGV0ZSIsImlkIiwid2luZG93IiwiY29uZmlybSIsImRlbGV0ZSIsInIiLCJfaWQiLCJhbGVydCIsInRhcmdldCIsInZhbHVlIiwibGVuZ3RoIiwicnVuYm9vayIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlJ1bmJvb2tzLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IGFwaSBmcm9tICcuLi9hcGkvYXhpb3MnO1xuXG5jb25zdCBSdW5ib29rcyA9ICgpID0+IHtcbiAgY29uc3QgW3J1bmJvb2tzLCBzZXRSdW5ib29rc10gPSB1c2VTdGF0ZShbXSk7XG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xuICBjb25zdCBbdXBsb2FkaW5nLCBzZXRVcGxvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKTtcbiAgXG4gIGNvbnN0IFtmb3JtLCBzZXRGb3JtXSA9IHVzZVN0YXRlKHsgdGl0bGU6ICcnLCB0YWdzOiAnJyB9KTtcbiAgY29uc3QgW2NvbnRlbnQsIHNldENvbnRlbnRdID0gdXNlU3RhdGUoJycpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgZmV0Y2hSdW5ib29rcygpO1xuICB9LCBbXSk7XG5cbiAgY29uc3QgZmV0Y2hSdW5ib29rcyA9IGFzeW5jICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBkYXRhIH0gPSBhd2FpdCBhcGkuZ2V0KCcvcnVuYm9va3MnKTtcbiAgICAgIHNldFJ1bmJvb2tzKGRhdGEuZGF0YSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzZXRFcnJvcignRmFpbGVkIHRvIGxvYWQgcnVuYm9va3MuJyk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBoYW5kbGVVcGxvYWQgPSBhc3luYyAoZSkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBzZXRVcGxvYWRpbmcodHJ1ZSk7XG4gICAgc2V0RXJyb3IoJycpO1xuXG4gICAgdHJ5IHtcbiAgICAgIC8vIFRhZ3MgY29tZSBpbiBhcyBhIGNvbW1hIHNlcGFyYXRlZCBzdHJpbmcsIHNwbGl0IHRoZW0gaW50byBhbiBhcnJheVxuICAgICAgY29uc3QgdGFnc0FycmF5ID0gZm9ybS50YWdzLnNwbGl0KCcsJykubWFwKHRhZyA9PiB0YWcudHJpbSgpKS5maWx0ZXIodGFnID0+IHRhZyk7XG5cbiAgICAgIGF3YWl0IGFwaS5wb3N0KCcvcnVuYm9va3MnLCB7XG4gICAgICAgIHRpdGxlOiBmb3JtLnRpdGxlLFxuICAgICAgICBjb250ZW50OiBjb250ZW50LFxuICAgICAgICB0YWdzOiB0YWdzQXJyYXlcbiAgICAgIH0pO1xuXG4gICAgICAvLyBSZXNldCBmb3JtIGFuZCByZWZyZXNoIGxpc3RcbiAgICAgIHNldEZvcm0oeyB0aXRsZTogJycsIHRhZ3M6ICcnIH0pO1xuICAgICAgc2V0Q29udGVudCgnJyk7XG4gICAgICBmZXRjaFJ1bmJvb2tzKCk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzZXRFcnJvcihlcnIucmVzcG9uc2U/LmRhdGE/LmVycm9yIHx8ICdGYWlsZWQgdG8gdXBsb2FkIHJ1bmJvb2snKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0VXBsb2FkaW5nKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlRGVsZXRlID0gYXN5bmMgKGlkKSA9PiB7XG4gICAgaWYgKCF3aW5kb3cuY29uZmlybShcIkFyZSB5b3Ugc3VyZSB5b3Ugd2FudCB0byBkZWxldGUgdGhpcyBydW5ib29rP1wiKSkgcmV0dXJuO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBhcGkuZGVsZXRlKGAvcnVuYm9va3MvJHtpZH1gKTtcbiAgICAgIHNldFJ1bmJvb2tzKHJ1bmJvb2tzLmZpbHRlcihyID0+IHIuX2lkICE9PSBpZCkpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgYWxlcnQoXCJGYWlsZWQgdG8gZGVsZXRlIHJ1bmJvb2tcIik7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy02eGwgbXgtYXV0byBncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0zIGdhcC04XCI+XG4gICAgICB7LyogTEVGVCBDT0xVTU46IFVwbG9hZCBGb3JtICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpjb2wtc3Bhbi0xIHNwYWNlLXktNlwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC13aGl0ZVwiPktub3dsZWRnZSBCYXNlPC9oMT5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCB0ZXh0LXNtXCI+VXBsb2FkIHJ1bmJvb2tzIHRvIHRyYWluIHRoZSBBSTwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVVwbG9hZH0gY2xhc3NOYW1lPVwiYmctc2xhdGUtODAwIHJvdW5kZWQteGwgcC02IGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHNwYWNlLXktNFwiPlxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIGZvbnQtbWVkaXVtIG1iLTRcIj5BZGQgTmV3IFJ1bmJvb2s8L2gyPlxuICAgICAgICAgIFxuICAgICAgICAgIHtlcnJvciAmJiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTQwMCB0ZXh0LXNtIGJnLXJlZC01MDAvMTAgcC0zIHJvdW5kZWRcIj57ZXJyb3J9PC9kaXY+fVxuXG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCB0ZXh0LXNtIG1iLTEgYmxvY2tcIj5UaXRsZTwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICB2YWx1ZT17Zm9ybS50aXRsZX1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtKHsgLi4uZm9ybSwgdGl0bGU6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNjAwIHRleHQtd2hpdGUgcm91bmRlZC1sZyBweC00IHB5LTIgdGV4dC1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWluZGlnby01MDBcIlxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4sIEZpeCBOb2RlLmpzIE9PTSBDcmFzaFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCB0ZXh0LXNtIG1iLTEgYmxvY2tcIj5Db250ZW50IC8gU3RlcHM8L2xhYmVsPlxuICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgIHJvd3M9XCI2XCJcbiAgICAgICAgICAgICAgdmFsdWU9e2NvbnRlbnR9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q29udGVudChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS02MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIHB4LTQgcHktMiB0ZXh0LXNtIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItaW5kaWdvLTUwMFwiXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMS4gU1NIIGludG8gc2VydmVyLi4uJiMxMDsyLiBSZXN0YXJ0IFBNMi4uLiYjMTA7My4gQ2hlY2sgbG9ncy4uLlwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCB0ZXh0LXNtIG1iLTEgYmxvY2tcIj5UYWdzIChjb21tYSBzZXBhcmF0ZWQpPC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgIHZhbHVlPXtmb3JtLnRhZ3N9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybSh7IC4uLmZvcm0sIHRhZ3M6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNjAwIHRleHQtd2hpdGUgcm91bmRlZC1sZyBweC00IHB5LTIgdGV4dC1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWluZGlnby01MDBcIlxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIm5vZGVqcywgbWVtb3J5LCBjcmFzaFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICBkaXNhYmxlZD17dXBsb2FkaW5nfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLWluZGlnby02MDAgaG92ZXI6YmctaW5kaWdvLTcwMCBkaXNhYmxlZDpvcGFjaXR5LTUwIHRleHQtd2hpdGUgcHktMi41IHJvdW5kZWQtbGcgZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1jb2xvcnMgdGV4dC1zbVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAge3VwbG9hZGluZyA/ICdFbWJlZGRpbmcgYW5kIFNhdmluZy4uLicgOiAnVXBsb2FkICYgVHJhaW4gQUknfVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Zvcm0+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFJJR0hUIENPTFVNTjogUnVuYm9va3MgTGlzdCAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6Y29sLXNwYW4tMlwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTgwMCByb3VuZGVkLXhsIHAtNiBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCBtaW4taC1mdWxsXCI+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgZm9udC1tZWRpdW0gbWItNlwiPkFjdGl2ZSBSdW5ib29rcyAoe3J1bmJvb2tzLmxlbmd0aH0pPC9oMj5cbiAgICAgICAgICBcbiAgICAgICAgICB7bG9hZGluZyA/IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1pbmRpZ28tNDAwIGFuaW1hdGUtcHVsc2UgdGV4dC1zbVwiPkxvYWRpbmcgZGF0YWJhc2UuLi48L2Rpdj5cbiAgICAgICAgICApIDogcnVuYm9va3MubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCB0ZXh0LWNlbnRlciBweS0xMlwiPlxuICAgICAgICAgICAgICBObyBydW5ib29rcyBmb3VuZC4gQWRkIG9uZSB0byBwb3dlciB1cCB0aGUgQUkncyBUaWVyIDEgbWF0Y2hpbmcuXG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAge3J1bmJvb2tzLm1hcCgocnVuYm9vaykgPT4gKFxuICAgICAgICAgICAgICAgIDxkaXYga2V5PXtydW5ib29rLl9pZH0gY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIHJvdW5kZWQtbGcgcC01IGJvcmRlciBib3JkZXItc2xhdGUtNzAwXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLXN0YXJ0IG1iLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtaW5kaWdvLTQwMCBmb250LW1lZGl1bVwiPntydW5ib29rLnRpdGxlfTwvaDM+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlKHJ1bmJvb2suX2lkKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBob3Zlcjp0ZXh0LXJlZC00MDAgdGV4dC1zbSB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICBEZWxldGVcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMzAwIHRleHQtc20gbWItMyBsaW5lLWNsYW1wLTJcIj57cnVuYm9vay5jb250ZW50fTwvcD5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICB7cnVuYm9vay50YWdzLm1hcCh0YWcgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGtleT17dGFnfSBjbGFzc05hbWU9XCJiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS00MDAgcHgtMiBweS0wLjUgcm91bmRlZCB0ZXh0LXhzIGJvcmRlciBib3JkZXItc2xhdGUtNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAje3RhZ31cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IFJ1bmJvb2tzO1xuIl0sImZpbGUiOiJDOi9Vc2Vycy9BbWl0aCBVIE5heWFrLy5nZW1pbmkvYW50aWdyYXZpdHkvc2NyYXRjaC9vcHNnZW5pZWFpL2NsaWVudC9zcmMvcGFnZXMvUnVuYm9va3MuanN4In0=