import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Sidebar.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1aa83cf1"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/Sidebar.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { NavLink, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=3fc0a56c";
import { useAuth } from "/src/context/AuthContext.jsx";
const navItems = [
  { to: "/dashboard", icon: "📊", label: "Dashboard" },
  { to: "/incidents", icon: "🚨", label: "Incidents" },
  { to: "/incidents/new", icon: "➕", label: "New Incident" },
  { to: "/runbooks", icon: "📖", label: "Runbooks" }
];
const Sidebar = () => {
  _s();
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const handleLogout = () => {
    logout();
    navigate("/login");
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "w-64 bg-slate-800 h-screen flex flex-col fixed left-0 top-0 border-r border-slate-700", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "p-6 border-b border-slate-700", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-xl font-bold text-white", children: "⚡ OpsIncidentAI" }, void 0, false, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/Sidebar.jsx",
        lineNumber: 43,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-slate-400 text-xs mt-1", children: "AI Incident Management" }, void 0, false, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/Sidebar.jsx",
        lineNumber: 44,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/Sidebar.jsx",
      lineNumber: 42,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("nav", { className: "flex-1 p-4 space-y-1", children: navItems.map(
      (item) => /* @__PURE__ */ jsxDEV(
        NavLink,
        {
          to: item.to,
          className: ({ isActive }) => `flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${isActive ? "bg-indigo-600 text-white" : "text-slate-400 hover:bg-slate-700 hover:text-white"}`,
          children: [
            /* @__PURE__ */ jsxDEV("span", { children: item.icon }, void 0, false, {
              fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/Sidebar.jsx",
              lineNumber: 61,
              columnNumber: 13
            }, this),
            item.label
          ]
        },
        item.to,
        true,
        {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/Sidebar.jsx",
          lineNumber: 50,
          columnNumber: 9
        },
        this
      )
    ) }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/Sidebar.jsx",
      lineNumber: 48,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p-4 border-t border-slate-700", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-3", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 bg-indigo-600 rounded-full flex items-center justify-center text-white text-sm font-bold", children: user?.name?.charAt(0).toUpperCase() }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/Sidebar.jsx",
          lineNumber: 70,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-white text-sm font-medium", children: user?.name }, void 0, false, {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/Sidebar.jsx",
            lineNumber: 74,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-slate-400 text-xs capitalize", children: user?.role }, void 0, false, {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/Sidebar.jsx",
            lineNumber: 75,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/Sidebar.jsx",
          lineNumber: 73,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/Sidebar.jsx",
        lineNumber: 69,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: handleLogout,
          className: "w-full text-left px-4 py-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded-lg text-sm transition-colors",
          children: "🚪 Logout"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/Sidebar.jsx",
          lineNumber: 78,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/Sidebar.jsx",
      lineNumber: 68,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/Sidebar.jsx",
    lineNumber: 40,
    columnNumber: 5
  }, this);
};
_s(Sidebar, "owExUWFylk0vVlQUKU4QcBpCg7Y=", false, function() {
  return [useAuth, useNavigate];
});
_c = Sidebar;
export default Sidebar;
var _c;
$RefreshReg$(_c, "Sidebar");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/Sidebar.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/Sidebar.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUJROzs7Ozs7Ozs7Ozs7Ozs7OztBQXZCUixTQUFTQSxTQUFTQyxtQkFBbUI7QUFDckMsU0FBU0MsZUFBZTtBQUV4QixNQUFNQyxXQUFXO0FBQUEsRUFDZixFQUFFQyxJQUFJLGNBQWNDLE1BQU0sTUFBTUMsT0FBTyxZQUFZO0FBQUEsRUFDbkQsRUFBRUYsSUFBSSxjQUFjQyxNQUFNLE1BQU1DLE9BQU8sWUFBWTtBQUFBLEVBQ25ELEVBQUVGLElBQUksa0JBQWtCQyxNQUFNLEtBQUtDLE9BQU8sZUFBZTtBQUFBLEVBQ3pELEVBQUVGLElBQUksYUFBYUMsTUFBTSxNQUFNQyxPQUFPLFdBQVc7QUFBQztBQUdwRCxNQUFNQyxVQUFVQSxNQUFNO0FBQUFDLEtBQUE7QUFDcEIsUUFBTSxFQUFFQyxNQUFNQyxPQUFPLElBQUlSLFFBQVE7QUFDakMsUUFBTVMsV0FBV1YsWUFBWTtBQUU3QixRQUFNVyxlQUFlQSxNQUFNO0FBQ3pCRixXQUFPO0FBQ1BDLGFBQVMsUUFBUTtBQUFBLEVBQ25CO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUseUZBRWI7QUFBQSwyQkFBQyxTQUFJLFdBQVUsaUNBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsZ0NBQStCLCtCQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTREO0FBQUEsTUFDNUQsdUJBQUMsT0FBRSxXQUFVLCtCQUE4QixzQ0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRTtBQUFBLFNBRm5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNaUixtQkFBU1U7QUFBQUEsTUFBSSxDQUFDQyxTQUNiO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFQyxJQUFJQSxLQUFLVjtBQUFBQSxVQUNULFdBQVcsQ0FBQyxFQUFFVyxTQUFTLE1BQ3JCLHNGQUNFQSxXQUNJLDZCQUNBLG9EQUFvRDtBQUFBLFVBSTVEO0FBQUEsbUNBQUMsVUFBTUQsZUFBS1QsUUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQjtBQUFBLFlBQ2hCUyxLQUFLUjtBQUFBQTtBQUFBQTtBQUFBQSxRQVhEUSxLQUFLVjtBQUFBQSxRQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFhQTtBQUFBLElBQ0QsS0FoQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLGlDQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLG9HQUNaSyxnQkFBTU8sTUFBTUMsT0FBTyxDQUFDLEVBQUVDLFlBQVksS0FEckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsT0FBRSxXQUFVLGtDQUFrQ1QsZ0JBQU1PLFFBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBEO0FBQUEsVUFDMUQsdUJBQUMsT0FBRSxXQUFVLHFDQUFxQ1AsZ0JBQU1VLFFBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZEO0FBQUEsYUFGL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTUDtBQUFBQSxVQUNULFdBQVU7QUFBQSxVQUFvSDtBQUFBO0FBQUEsUUFGaEk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS0E7QUFBQSxTQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQkE7QUFBQSxPQTVDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNkNBO0FBRUo7QUFBRUosR0F6RElELFNBQU87QUFBQSxVQUNjTCxTQUNSRCxXQUFXO0FBQUE7QUFBQSxLQUZ4Qk07QUEyRE4sZUFBZUE7QUFBUSxJQUFBYTtBQUFBLGFBQUFBLElBQUEiLCJuYW1lcyI6WyJOYXZMaW5rIiwidXNlTmF2aWdhdGUiLCJ1c2VBdXRoIiwibmF2SXRlbXMiLCJ0byIsImljb24iLCJsYWJlbCIsIlNpZGViYXIiLCJfcyIsInVzZXIiLCJsb2dvdXQiLCJuYXZpZ2F0ZSIsImhhbmRsZUxvZ291dCIsIm1hcCIsIml0ZW0iLCJpc0FjdGl2ZSIsIm5hbWUiLCJjaGFyQXQiLCJ0b1VwcGVyQ2FzZSIsInJvbGUiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJTaWRlYmFyLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOYXZMaW5rLCB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uL2NvbnRleHQvQXV0aENvbnRleHQnO1xuXG5jb25zdCBuYXZJdGVtcyA9IFtcbiAgeyB0bzogJy9kYXNoYm9hcmQnLCBpY29uOiAn8J+TiicsIGxhYmVsOiAnRGFzaGJvYXJkJyB9LFxuICB7IHRvOiAnL2luY2lkZW50cycsIGljb246ICfwn5qoJywgbGFiZWw6ICdJbmNpZGVudHMnIH0sXG4gIHsgdG86ICcvaW5jaWRlbnRzL25ldycsIGljb246ICfinpUnLCBsYWJlbDogJ05ldyBJbmNpZGVudCcgfSxcbiAgeyB0bzogJy9ydW5ib29rcycsIGljb246ICfwn5OWJywgbGFiZWw6ICdSdW5ib29rcycgfSxcbl07XG5cbmNvbnN0IFNpZGViYXIgPSAoKSA9PiB7XG4gIGNvbnN0IHsgdXNlciwgbG9nb3V0IH0gPSB1c2VBdXRoKCk7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcblxuICBjb25zdCBoYW5kbGVMb2dvdXQgPSAoKSA9PiB7XG4gICAgbG9nb3V0KCk7XG4gICAgbmF2aWdhdGUoJy9sb2dpbicpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJ3LTY0IGJnLXNsYXRlLTgwMCBoLXNjcmVlbiBmbGV4IGZsZXgtY29sIGZpeGVkIGxlZnQtMCB0b3AtMCBib3JkZXItciBib3JkZXItc2xhdGUtNzAwXCI+XG4gICAgICB7LyogTG9nbyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IGJvcmRlci1iIGJvcmRlci1zbGF0ZS03MDBcIj5cbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtd2hpdGVcIj7imqEgT3BzSW5jaWRlbnRBSTwvaDE+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIHRleHQteHMgbXQtMVwiPkFJIEluY2lkZW50IE1hbmFnZW1lbnQ8L3A+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIE5hdiBMaW5rcyAqL31cbiAgICAgIDxuYXYgY2xhc3NOYW1lPVwiZmxleC0xIHAtNCBzcGFjZS15LTFcIj5cbiAgICAgICAge25hdkl0ZW1zLm1hcCgoaXRlbSkgPT4gKFxuICAgICAgICAgIDxOYXZMaW5rXG4gICAgICAgICAgICBrZXk9e2l0ZW0udG99XG4gICAgICAgICAgICB0bz17aXRlbS50b31cbiAgICAgICAgICAgIGNsYXNzTmFtZT17KHsgaXNBY3RpdmUgfSkgPT5cbiAgICAgICAgICAgICAgYGZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHB4LTQgcHktMyByb3VuZGVkLWxnIHRleHQtc20gZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1jb2xvcnMgJHtcbiAgICAgICAgICAgICAgICBpc0FjdGl2ZVxuICAgICAgICAgICAgICAgICAgPyAnYmctaW5kaWdvLTYwMCB0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICAgICAgOiAndGV4dC1zbGF0ZS00MDAgaG92ZXI6Ymctc2xhdGUtNzAwIGhvdmVyOnRleHQtd2hpdGUnXG4gICAgICAgICAgICAgIH1gXG4gICAgICAgICAgICB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPHNwYW4+e2l0ZW0uaWNvbn08L3NwYW4+XG4gICAgICAgICAgICB7aXRlbS5sYWJlbH1cbiAgICAgICAgICA8L05hdkxpbms+XG4gICAgICAgICkpfVxuICAgICAgPC9uYXY+XG5cbiAgICAgIHsvKiBVc2VyIGluZm8gKyBMb2dvdXQgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBib3JkZXItdCBib3JkZXItc2xhdGUtNzAwXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWItM1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCBiZy1pbmRpZ28tNjAwIHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXdoaXRlIHRleHQtc20gZm9udC1ib2xkXCI+XG4gICAgICAgICAgICB7dXNlcj8ubmFtZT8uY2hhckF0KDApLnRvVXBwZXJDYXNlKCl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgdGV4dC1zbSBmb250LW1lZGl1bVwiPnt1c2VyPy5uYW1lfTwvcD5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIHRleHQteHMgY2FwaXRhbGl6ZVwiPnt1c2VyPy5yb2xlfTwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVMb2dvdXR9XG4gICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtbGVmdCBweC00IHB5LTIgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSBob3ZlcjpiZy1zbGF0ZS03MDAgcm91bmRlZC1sZyB0ZXh0LXNtIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgPlxuICAgICAgICAgIPCfmqogTG9nb3V0XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBTaWRlYmFyO1xuIl0sImZpbGUiOiJDOi9Vc2Vycy9BbWl0aCBVIE5heWFrLy5nZW1pbmkvYW50aWdyYXZpdHkvc2NyYXRjaC9vcHNnZW5pZWFpL2NsaWVudC9zcmMvY29tcG9uZW50cy9TaWRlYmFyLmpzeCJ9