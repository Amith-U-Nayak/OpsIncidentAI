import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Incidents.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1aa83cf1"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=1aa83cf1"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=3fc0a56c";
import api from "/src/api/axios.js";
const SEVERITY_COLORS = {
  Critical: "bg-red-500/10 text-red-400 border-red-500/20",
  High: "bg-orange-500/10 text-orange-400 border-orange-500/20",
  Medium: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20",
  Low: "bg-blue-500/10 text-blue-400 border-blue-500/20"
};
const STATUS_COLORS = {
  Open: "bg-slate-700 text-slate-300",
  Investigating: "bg-indigo-500/10 text-indigo-400 border-indigo-500/20",
  Resolved: "bg-green-500/10 text-green-400 border-green-500/20",
  Closed: "bg-slate-800 text-slate-500"
};
const Incidents = () => {
  _s();
  const [incidents, setIncidents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const navigate = useNavigate();
  useEffect(() => {
    const fetchIncidents = async () => {
      try {
        const { data } = await api.get("/incidents");
        setIncidents(data.data);
      } catch (err) {
        setError("Failed to load incidents.");
      } finally {
        setLoading(false);
      }
    };
    fetchIncidents();
  }, []);
  if (loading) {
    return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center h-full", children: /* @__PURE__ */ jsxDEV("div", { className: "text-indigo-400 animate-pulse text-lg", children: "Loading Incidents..." }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
      lineNumber: 61,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
      lineNumber: 60,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "max-w-6xl mx-auto", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-6", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-white", children: "Incidents" }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
          lineNumber: 70,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-slate-400 text-sm", children: "Manage and track system issues" }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
          lineNumber: 71,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
        lineNumber: 69,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Link,
        {
          to: "/incidents/new",
          className: "bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg font-medium transition-colors shadow-lg shadow-indigo-500/20",
          children: "➕ New Incident"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
          lineNumber: 73,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
      lineNumber: 68,
      columnNumber: 7
    }, this),
    error && /* @__PURE__ */ jsxDEV("div", { className: "bg-red-500/10 border border-red-500 text-red-400 p-4 rounded-lg mb-6", children: error }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
      lineNumber: 82,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-slate-800 rounded-xl border border-slate-700 overflow-hidden", children: /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxDEV("table", { className: "w-full text-left border-collapse", children: [
      /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { className: "bg-slate-900/50 border-b border-slate-700 text-slate-400 text-sm", children: [
        /* @__PURE__ */ jsxDEV("th", { className: "p-4 font-medium", children: "Title" }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
          lineNumber: 93,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "p-4 font-medium", children: "Status" }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
          lineNumber: 94,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "p-4 font-medium", children: "Severity" }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
          lineNumber: 95,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "p-4 font-medium", children: "Created At" }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
          lineNumber: 96,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "p-4 font-medium text-right", children: "Action" }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
          lineNumber: 97,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
        lineNumber: 92,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
        lineNumber: 91,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("tbody", { className: "divide-y divide-slate-700", children: incidents.length === 0 ? /* @__PURE__ */ jsxDEV("tr", { children: /* @__PURE__ */ jsxDEV("td", { colSpan: "5", className: "p-8 text-center text-slate-500", children: "No incidents found. You're all clear! 🎉" }, void 0, false, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
        lineNumber: 103,
        columnNumber: 19
      }, this) }, void 0, false, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
        lineNumber: 102,
        columnNumber: 15
      }, this) : incidents.map(
        (incident) => /* @__PURE__ */ jsxDEV(
          "tr",
          {
            className: "hover:bg-slate-700/50 transition-colors cursor-pointer group",
            onClick: () => navigate(`/incidents/${incident._id}`),
            children: [
              /* @__PURE__ */ jsxDEV("td", { className: "p-4 text-white font-medium", children: [
                incident.title,
                /* @__PURE__ */ jsxDEV("p", { className: "text-slate-400 text-xs mt-1 truncate max-w-md font-normal", children: incident.description }, void 0, false, {
                  fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
                  lineNumber: 117,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
                lineNumber: 114,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "p-4", children: /* @__PURE__ */ jsxDEV("span", { className: `px-2.5 py-1 rounded-full text-xs font-medium border ${STATUS_COLORS[incident.status]}`, children: incident.status }, void 0, false, {
                fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
                lineNumber: 122,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
                lineNumber: 121,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "p-4", children: /* @__PURE__ */ jsxDEV("span", { className: `px-2.5 py-1 rounded-full text-xs font-medium border ${SEVERITY_COLORS[incident.severity]}`, children: incident.severity }, void 0, false, {
                fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
                lineNumber: 127,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
                lineNumber: 126,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "p-4 text-slate-400 text-sm", children: new Date(incident.createdAt).toLocaleDateString() }, void 0, false, {
                fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
                lineNumber: 131,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("td", { className: "p-4 text-right", children: /* @__PURE__ */ jsxDEV("span", { className: "text-indigo-400 group-hover:text-indigo-300 font-medium text-sm transition-colors", children: "View Details →" }, void 0, false, {
                fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
                lineNumber: 135,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
                lineNumber: 134,
                columnNumber: 21
              }, this)
            ]
          },
          incident._id,
          true,
          {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
            lineNumber: 109,
            columnNumber: 15
          },
          this
        )
      ) }, void 0, false, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
        lineNumber: 100,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
      lineNumber: 90,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
      lineNumber: 89,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
      lineNumber: 88,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx",
    lineNumber: 67,
    columnNumber: 5
  }, this);
};
_s(Incidents, "JeSvsGMY8vLw+ynER6476XFmCT8=", false, function() {
  return [useNavigate];
});
_c = Incidents;
export default Incidents;
var _c;
$RefreshReg$(_c, "Incidents");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Incidents.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUNROzs7Ozs7Ozs7Ozs7Ozs7OztBQXpDUixTQUFTQSxVQUFVQyxpQkFBaUI7QUFDcEMsU0FBU0MsTUFBTUMsbUJBQW1CO0FBQ2xDLE9BQU9DLFNBQVM7QUFFaEIsTUFBTUMsa0JBQWtCO0FBQUEsRUFDdEJDLFVBQVU7QUFBQSxFQUNWQyxNQUFNO0FBQUEsRUFDTkMsUUFBUTtBQUFBLEVBQ1JDLEtBQUs7QUFDUDtBQUVBLE1BQU1DLGdCQUFnQjtBQUFBLEVBQ3BCQyxNQUFNO0FBQUEsRUFDTkMsZUFBZTtBQUFBLEVBQ2ZDLFVBQVU7QUFBQSxFQUNWQyxRQUFRO0FBQ1Y7QUFFQSxNQUFNQyxZQUFZQSxNQUFNO0FBQUFDLEtBQUE7QUFDdEIsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUlsQixTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDbUIsU0FBU0MsVUFBVSxJQUFJcEIsU0FBUyxJQUFJO0FBQzNDLFFBQU0sQ0FBQ3FCLE9BQU9DLFFBQVEsSUFBSXRCLFNBQVMsRUFBRTtBQUNyQyxRQUFNdUIsV0FBV3BCLFlBQVk7QUFFN0JGLFlBQVUsTUFBTTtBQUNkLFVBQU11QixpQkFBaUIsWUFBWTtBQUNqQyxVQUFJO0FBQ0YsY0FBTSxFQUFFQyxLQUFLLElBQUksTUFBTXJCLElBQUlzQixJQUFJLFlBQVk7QUFDM0NSLHFCQUFhTyxLQUFLQSxJQUFJO0FBQUEsTUFDeEIsU0FBU0UsS0FBSztBQUNaTCxpQkFBUywyQkFBMkI7QUFBQSxNQUN0QyxVQUFDO0FBQ0NGLG1CQUFXLEtBQUs7QUFBQSxNQUNsQjtBQUFBLElBQ0Y7QUFDQUksbUJBQWU7QUFBQSxFQUNqQixHQUFHLEVBQUU7QUFFTCxNQUFJTCxTQUFTO0FBQ1gsV0FDRSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2IsaUNBQUMsU0FBSSxXQUFVLHlDQUF3QyxvQ0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyRSxLQUQ3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSw2QkFBQyxTQUNDO0FBQUEsK0JBQUMsUUFBRyxXQUFVLGlDQUFnQyx5QkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RDtBQUFBLFFBQ3ZELHVCQUFDLE9BQUUsV0FBVSwwQkFBeUIsOENBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0U7QUFBQSxXQUZ0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxJQUFHO0FBQUEsVUFDSCxXQUFVO0FBQUEsVUFBZ0k7QUFBQTtBQUFBLFFBRjVJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtBO0FBQUEsU0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0E7QUFBQSxJQUVDRSxTQUNDLHVCQUFDLFNBQUksV0FBVSx3RUFDWkEsbUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFJRix1QkFBQyxTQUFJLFdBQVUsbUVBQ2IsaUNBQUMsU0FBSSxXQUFVLG1CQUNiLGlDQUFDLFdBQU0sV0FBVSxvQ0FDZjtBQUFBLDZCQUFDLFdBQ0MsaUNBQUMsUUFBRyxXQUFVLG9FQUNaO0FBQUEsK0JBQUMsUUFBRyxXQUFVLG1CQUFrQixxQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxQztBQUFBLFFBQ3JDLHVCQUFDLFFBQUcsV0FBVSxtQkFBa0Isc0JBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0M7QUFBQSxRQUN0Qyx1QkFBQyxRQUFHLFdBQVUsbUJBQWtCLHdCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdDO0FBQUEsUUFDeEMsdUJBQUMsUUFBRyxXQUFVLG1CQUFrQiwwQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQztBQUFBLFFBQzFDLHVCQUFDLFFBQUcsV0FBVSw4QkFBNkIsc0JBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUQ7QUFBQSxXQUxuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUNBLHVCQUFDLFdBQU0sV0FBVSw2QkFDZEosb0JBQVVXLFdBQVcsSUFDcEIsdUJBQUMsUUFDQyxpQ0FBQyxRQUFHLFNBQVEsS0FBSSxXQUFVLGtDQUFnQyx3REFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBLElBRUFYLFVBQVVZO0FBQUFBLFFBQUksQ0FBQ0MsYUFDYjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRUMsV0FBVTtBQUFBLFlBQ1YsU0FBUyxNQUFNUCxTQUFTLGNBQWNPLFNBQVNDLEdBQUcsRUFBRTtBQUFBLFlBRXBEO0FBQUEscUNBQUMsUUFBRyxXQUFVLDhCQUNYRDtBQUFBQSx5QkFBU0U7QUFBQUEsZ0JBRVYsdUJBQUMsT0FBRSxXQUFVLDZEQUNWRixtQkFBU0csZUFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFNQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxXQUFVLE9BQ1osaUNBQUMsVUFBSyxXQUFXLHVEQUF1RHZCLGNBQWNvQixTQUFTSSxNQUFNLENBQUMsSUFDbkdKLG1CQUFTSSxVQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsY0FDQSx1QkFBQyxRQUFHLFdBQVUsT0FDWixpQ0FBQyxVQUFLLFdBQVcsdURBQXVEN0IsZ0JBQWdCeUIsU0FBU0ssUUFBUSxDQUFDLElBQ3ZHTCxtQkFBU0ssWUFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJQTtBQUFBLGNBQ0EsdUJBQUMsUUFBRyxXQUFVLDhCQUNYLGNBQUlDLEtBQUtOLFNBQVNPLFNBQVMsRUFBRUMsbUJBQW1CLEtBRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFFBQUcsV0FBVSxrQkFDWixpQ0FBQyxVQUFLLFdBQVUscUZBQW1GLDhCQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJQTtBQUFBO0FBQUE7QUFBQSxVQTVCS1IsU0FBU0M7QUFBQUEsVUFEaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQThCQTtBQUFBLE1BQ0QsS0F4Q0w7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBDQTtBQUFBLFNBcERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxREEsS0F0REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVEQSxLQXhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeURBO0FBQUEsT0E5RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQStFQTtBQUVKO0FBQUVmLEdBOUdJRCxXQUFTO0FBQUEsVUFJSVosV0FBVztBQUFBO0FBQUEsS0FKeEJZO0FBZ0hOLGVBQWVBO0FBQVUsSUFBQXdCO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwiTGluayIsInVzZU5hdmlnYXRlIiwiYXBpIiwiU0VWRVJJVFlfQ09MT1JTIiwiQ3JpdGljYWwiLCJIaWdoIiwiTWVkaXVtIiwiTG93IiwiU1RBVFVTX0NPTE9SUyIsIk9wZW4iLCJJbnZlc3RpZ2F0aW5nIiwiUmVzb2x2ZWQiLCJDbG9zZWQiLCJJbmNpZGVudHMiLCJfcyIsImluY2lkZW50cyIsInNldEluY2lkZW50cyIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiZXJyb3IiLCJzZXRFcnJvciIsIm5hdmlnYXRlIiwiZmV0Y2hJbmNpZGVudHMiLCJkYXRhIiwiZ2V0IiwiZXJyIiwibGVuZ3RoIiwibWFwIiwiaW5jaWRlbnQiLCJfaWQiLCJ0aXRsZSIsImRlc2NyaXB0aW9uIiwic3RhdHVzIiwic2V2ZXJpdHkiLCJEYXRlIiwiY3JlYXRlZEF0IiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiSW5jaWRlbnRzLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgTGluaywgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCBhcGkgZnJvbSAnLi4vYXBpL2F4aW9zJztcblxuY29uc3QgU0VWRVJJVFlfQ09MT1JTID0ge1xuICBDcml0aWNhbDogJ2JnLXJlZC01MDAvMTAgdGV4dC1yZWQtNDAwIGJvcmRlci1yZWQtNTAwLzIwJyxcbiAgSGlnaDogJ2JnLW9yYW5nZS01MDAvMTAgdGV4dC1vcmFuZ2UtNDAwIGJvcmRlci1vcmFuZ2UtNTAwLzIwJyxcbiAgTWVkaXVtOiAnYmcteWVsbG93LTUwMC8xMCB0ZXh0LXllbGxvdy00MDAgYm9yZGVyLXllbGxvdy01MDAvMjAnLFxuICBMb3c6ICdiZy1ibHVlLTUwMC8xMCB0ZXh0LWJsdWUtNDAwIGJvcmRlci1ibHVlLTUwMC8yMCcsXG59O1xuXG5jb25zdCBTVEFUVVNfQ09MT1JTID0ge1xuICBPcGVuOiAnYmctc2xhdGUtNzAwIHRleHQtc2xhdGUtMzAwJyxcbiAgSW52ZXN0aWdhdGluZzogJ2JnLWluZGlnby01MDAvMTAgdGV4dC1pbmRpZ28tNDAwIGJvcmRlci1pbmRpZ28tNTAwLzIwJyxcbiAgUmVzb2x2ZWQ6ICdiZy1ncmVlbi01MDAvMTAgdGV4dC1ncmVlbi00MDAgYm9yZGVyLWdyZWVuLTUwMC8yMCcsXG4gIENsb3NlZDogJ2JnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTUwMCcsXG59O1xuXG5jb25zdCBJbmNpZGVudHMgPSAoKSA9PiB7XG4gIGNvbnN0IFtpbmNpZGVudHMsIHNldEluY2lkZW50c10gPSB1c2VTdGF0ZShbXSk7XG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgZmV0Y2hJbmNpZGVudHMgPSBhc3luYyAoKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IGFwaS5nZXQoJy9pbmNpZGVudHMnKTtcbiAgICAgICAgc2V0SW5jaWRlbnRzKGRhdGEuZGF0YSk7XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgc2V0RXJyb3IoJ0ZhaWxlZCB0byBsb2FkIGluY2lkZW50cy4nKTtcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgfVxuICAgIH07XG4gICAgZmV0Y2hJbmNpZGVudHMoKTtcbiAgfSwgW10pO1xuXG4gIGlmIChsb2FkaW5nKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgaC1mdWxsXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1pbmRpZ28tNDAwIGFuaW1hdGUtcHVsc2UgdGV4dC1sZ1wiPkxvYWRpbmcgSW5jaWRlbnRzLi4uPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTZ4bCBteC1hdXRvXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi02XCI+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXdoaXRlXCI+SW5jaWRlbnRzPC9oMT5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCB0ZXh0LXNtXCI+TWFuYWdlIGFuZCB0cmFjayBzeXN0ZW0gaXNzdWVzPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPExpbmsgXG4gICAgICAgICAgdG89XCIvaW5jaWRlbnRzL25ld1wiIFxuICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWluZGlnby02MDAgaG92ZXI6YmctaW5kaWdvLTcwMCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkLWxnIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tY29sb3JzIHNoYWRvdy1sZyBzaGFkb3ctaW5kaWdvLTUwMC8yMFwiXG4gICAgICAgID5cbiAgICAgICAgICDinpUgTmV3IEluY2lkZW50XG4gICAgICAgIDwvTGluaz5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7ZXJyb3IgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXJlZC01MDAvMTAgYm9yZGVyIGJvcmRlci1yZWQtNTAwIHRleHQtcmVkLTQwMCBwLTQgcm91bmRlZC1sZyBtYi02XCI+XG4gICAgICAgICAge2Vycm9yfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBIQ0kgUHJpbmNpcGxlOiBEYXRhIFRhYmxlcyBzaG91bGQgYmUgZWFzeSB0byBzY2FuLiBVc2UgYmFkZ2VzIGFuZCB6ZWJyYSBzdHJpcGluZyBvciBob3ZlciBzdGF0ZXMuICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS04MDAgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG9cIj5cbiAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtbGVmdCBib3JkZXItY29sbGFwc2VcIj5cbiAgICAgICAgICAgIDx0aGVhZD5cbiAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMC81MCBib3JkZXItYiBib3JkZXItc2xhdGUtNzAwIHRleHQtc2xhdGUtNDAwIHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC00IGZvbnQtbWVkaXVtXCI+VGl0bGU8L3RoPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTQgZm9udC1tZWRpdW1cIj5TdGF0dXM8L3RoPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTQgZm9udC1tZWRpdW1cIj5TZXZlcml0eTwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtNCBmb250LW1lZGl1bVwiPkNyZWF0ZWQgQXQ8L3RoPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTQgZm9udC1tZWRpdW0gdGV4dC1yaWdodFwiPkFjdGlvbjwvdGg+XG4gICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICA8L3RoZWFkPlxuICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1zbGF0ZS03MDBcIj5cbiAgICAgICAgICAgICAge2luY2lkZW50cy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgPHRkIGNvbFNwYW49XCI1XCIgY2xhc3NOYW1lPVwicC04IHRleHQtY2VudGVyIHRleHQtc2xhdGUtNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgIE5vIGluY2lkZW50cyBmb3VuZC4gWW91J3JlIGFsbCBjbGVhciEg8J+OiVxuICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIGluY2lkZW50cy5tYXAoKGluY2lkZW50KSA9PiAoXG4gICAgICAgICAgICAgICAgICA8dHIgXG4gICAgICAgICAgICAgICAgICAgIGtleT17aW5jaWRlbnQuX2lkfSBcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaG92ZXI6Ymctc2xhdGUtNzAwLzUwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyIGdyb3VwXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoYC9pbmNpZGVudHMvJHtpbmNpZGVudC5faWR9YCl9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTQgdGV4dC13aGl0ZSBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtpbmNpZGVudC50aXRsZX1cbiAgICAgICAgICAgICAgICAgICAgICB7LyogVHJ1bmNhdGUgbG9uZyBkZXNjcmlwdGlvbnMgdG8gcHJldmVudCBVSSBicmVha2luZyAqL31cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCB0ZXh0LXhzIG10LTEgdHJ1bmNhdGUgbWF4LXctbWQgZm9udC1ub3JtYWxcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtpbmNpZGVudC5kZXNjcmlwdGlvbn1cbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yLjUgcHktMSByb3VuZGVkLWZ1bGwgdGV4dC14cyBmb250LW1lZGl1bSBib3JkZXIgJHtTVEFUVVNfQ09MT1JTW2luY2lkZW50LnN0YXR1c119YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7aW5jaWRlbnQuc3RhdHVzfVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtNFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHB4LTIuNSBweS0xIHJvdW5kZWQtZnVsbCB0ZXh0LXhzIGZvbnQtbWVkaXVtIGJvcmRlciAke1NFVkVSSVRZX0NPTE9SU1tpbmNpZGVudC5zZXZlcml0eV19YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7aW5jaWRlbnQuc2V2ZXJpdHl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC00IHRleHQtc2xhdGUtNDAwIHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICAgICAgICB7bmV3IERhdGUoaW5jaWRlbnQuY3JlYXRlZEF0KS50b0xvY2FsZURhdGVTdHJpbmcoKX1cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtNCB0ZXh0LXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1pbmRpZ28tNDAwIGdyb3VwLWhvdmVyOnRleHQtaW5kaWdvLTMwMCBmb250LW1lZGl1bSB0ZXh0LXNtIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBWaWV3IERldGFpbHMg4oaSXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICApKVxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgSW5jaWRlbnRzO1xuIl0sImZpbGUiOiJDOi9Vc2Vycy9BbWl0aCBVIE5heWFrLy5nZW1pbmkvYW50aWdyYXZpdHkvc2NyYXRjaC9vcHNnZW5pZWFpL2NsaWVudC9zcmMvcGFnZXMvSW5jaWRlbnRzLmpzeCJ9