import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/context/AuthContext.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1aa83cf1"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/context/AuthContext.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=1aa83cf1"; const createContext = __vite__cjsImport3_react["createContext"]; const useContext = __vite__cjsImport3_react["useContext"]; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
const AuthContext = createContext(null);
export const AuthProvider = ({ children }) => {
  _s();
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const savedToken = localStorage.getItem("token");
    const savedUser = localStorage.getItem("user");
    if (savedToken && savedUser) {
      setToken(savedToken);
      setUser(JSON.parse(savedUser));
    }
    setLoading(false);
  }, []);
  const login = (userData, jwtToken) => {
    setUser(userData);
    setToken(jwtToken);
    localStorage.setItem("token", jwtToken);
    localStorage.setItem("user", JSON.stringify(userData));
  };
  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem("token");
    localStorage.removeItem("user");
  };
  return /* @__PURE__ */ jsxDEV(AuthContext.Provider, { value: { user, token, login, logout, loading }, children }, void 0, false, {
    fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/context/AuthContext.jsx",
    lineNumber: 57,
    columnNumber: 5
  }, this);
};
_s(AuthProvider, "uAkFQMmIUxfxJcQTEb8tCM/KFt4=");
_c = AuthProvider;
export const useAuth = () => {
  _s2();
  return useContext(AuthContext);
};
_s2(useAuth, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
var _c;
$RefreshReg$(_c, "AuthProvider");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/context/AuthContext.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/context/AuthContext.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUNJOzs7Ozs7Ozs7Ozs7Ozs7OztBQXJDSixTQUFTQSxlQUFlQyxZQUFZQyxVQUFVQyxpQkFBaUI7QUFJL0QsTUFBTUMsY0FBY0osY0FBYyxJQUFJO0FBRS9CLGFBQU1LLGVBQWVBLENBQUMsRUFBRUMsU0FBUyxNQUFNO0FBQUFDLEtBQUE7QUFDNUMsUUFBTSxDQUFDQyxNQUFNQyxPQUFPLElBQUlQLFNBQVMsSUFBSTtBQUNyQyxRQUFNLENBQUNRLE9BQU9DLFFBQVEsSUFBSVQsU0FBUyxJQUFJO0FBQ3ZDLFFBQU0sQ0FBQ1UsU0FBU0MsVUFBVSxJQUFJWCxTQUFTLElBQUk7QUFHM0NDLFlBQVUsTUFBTTtBQUNkLFVBQU1XLGFBQWFDLGFBQWFDLFFBQVEsT0FBTztBQUMvQyxVQUFNQyxZQUFZRixhQUFhQyxRQUFRLE1BQU07QUFDN0MsUUFBSUYsY0FBY0csV0FBVztBQUMzQk4sZUFBU0csVUFBVTtBQUNuQkwsY0FBUVMsS0FBS0MsTUFBTUYsU0FBUyxDQUFDO0FBQUEsSUFDL0I7QUFDQUosZUFBVyxLQUFLO0FBQUEsRUFDbEIsR0FBRyxFQUFFO0FBRUwsUUFBTU8sUUFBUUEsQ0FBQ0MsVUFBVUMsYUFBYTtBQUNwQ2IsWUFBUVksUUFBUTtBQUNoQlYsYUFBU1csUUFBUTtBQUNqQlAsaUJBQWFRLFFBQVEsU0FBU0QsUUFBUTtBQUN0Q1AsaUJBQWFRLFFBQVEsUUFBUUwsS0FBS00sVUFBVUgsUUFBUSxDQUFDO0FBQUEsRUFDdkQ7QUFFQSxRQUFNSSxTQUFTQSxNQUFNO0FBQ25CaEIsWUFBUSxJQUFJO0FBQ1pFLGFBQVMsSUFBSTtBQUNiSSxpQkFBYVcsV0FBVyxPQUFPO0FBQy9CWCxpQkFBYVcsV0FBVyxNQUFNO0FBQUEsRUFDaEM7QUFFQSxTQUNFLHVCQUFDLFlBQVksVUFBWixFQUFxQixPQUFPLEVBQUVsQixNQUFNRSxPQUFPVSxPQUFPSyxRQUFRYixRQUFRLEdBQ2hFTixZQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQTtBQUVKO0FBRUFDLEdBckNhRixjQUFZO0FBQUEsS0FBWkE7QUFzQ04sYUFBTXNCLFVBQVVBLE1BQUE7QUFBQUMsTUFBQTtBQUFBLFNBQU0zQixXQUFXRyxXQUFXO0FBQUM7QUFBQ3dCLElBQXhDRCxTQUFPO0FBQUEsSUFBQUU7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiY3JlYXRlQ29udGV4dCIsInVzZUNvbnRleHQiLCJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsIkF1dGhDb250ZXh0IiwiQXV0aFByb3ZpZGVyIiwiY2hpbGRyZW4iLCJfcyIsInVzZXIiLCJzZXRVc2VyIiwidG9rZW4iLCJzZXRUb2tlbiIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwic2F2ZWRUb2tlbiIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJzYXZlZFVzZXIiLCJKU09OIiwicGFyc2UiLCJsb2dpbiIsInVzZXJEYXRhIiwiand0VG9rZW4iLCJzZXRJdGVtIiwic3RyaW5naWZ5IiwibG9nb3V0IiwicmVtb3ZlSXRlbSIsInVzZUF1dGgiLCJfczIiLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBdXRoQ29udGV4dC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlQ29udGV4dCwgdXNlQ29udGV4dCwgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcblxuLy8gQXV0aENvbnRleHQgPSBnbG9iYWwgXCJidWxsZXRpbiBib2FyZFwiIHRoYXQgYW55IGNvbXBvbmVudCBjYW4gcmVhZFxuLy8gU3RvcmVzOiBjdXJyZW50IHVzZXIsIEpXVCB0b2tlbiwgbG9naW4vbG9nb3V0IGZ1bmN0aW9uc1xuY29uc3QgQXV0aENvbnRleHQgPSBjcmVhdGVDb250ZXh0KG51bGwpO1xuXG5leHBvcnQgY29uc3QgQXV0aFByb3ZpZGVyID0gKHsgY2hpbGRyZW4gfSkgPT4ge1xuICBjb25zdCBbdXNlciwgc2V0VXNlcl0gPSB1c2VTdGF0ZShudWxsKTtcbiAgY29uc3QgW3Rva2VuLCBzZXRUb2tlbl0gPSB1c2VTdGF0ZShudWxsKTtcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XG5cbiAgLy8gT24gYXBwIGxvYWQsIGNoZWNrIGlmIHVzZXIgd2FzIGFscmVhZHkgbG9nZ2VkIGluICh0b2tlbiBpbiBsb2NhbFN0b3JhZ2UpXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3Qgc2F2ZWRUb2tlbiA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKCd0b2tlbicpO1xuICAgIGNvbnN0IHNhdmVkVXNlciA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKCd1c2VyJyk7XG4gICAgaWYgKHNhdmVkVG9rZW4gJiYgc2F2ZWRVc2VyKSB7XG4gICAgICBzZXRUb2tlbihzYXZlZFRva2VuKTtcbiAgICAgIHNldFVzZXIoSlNPTi5wYXJzZShzYXZlZFVzZXIpKTtcbiAgICB9XG4gICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gIH0sIFtdKTtcblxuICBjb25zdCBsb2dpbiA9ICh1c2VyRGF0YSwgand0VG9rZW4pID0+IHtcbiAgICBzZXRVc2VyKHVzZXJEYXRhKTtcbiAgICBzZXRUb2tlbihqd3RUb2tlbik7XG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3Rva2VuJywgand0VG9rZW4pO1xuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCd1c2VyJywgSlNPTi5zdHJpbmdpZnkodXNlckRhdGEpKTtcbiAgfTtcblxuICBjb25zdCBsb2dvdXQgPSAoKSA9PiB7XG4gICAgc2V0VXNlcihudWxsKTtcbiAgICBzZXRUb2tlbihudWxsKTtcbiAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgndG9rZW4nKTtcbiAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgndXNlcicpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPEF1dGhDb250ZXh0LlByb3ZpZGVyIHZhbHVlPXt7IHVzZXIsIHRva2VuLCBsb2dpbiwgbG9nb3V0LCBsb2FkaW5nIH19PlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvQXV0aENvbnRleHQuUHJvdmlkZXI+XG4gICk7XG59O1xuXG4vLyBDdXN0b20gaG9vayDigJQgYW55IGNvbXBvbmVudCBjYW4gY2FsbCB1c2VBdXRoKCkgdG8gZ2V0IHRoZSBhdXRoIHN0YXRlXG5leHBvcnQgY29uc3QgdXNlQXV0aCA9ICgpID0+IHVzZUNvbnRleHQoQXV0aENvbnRleHQpO1xuIl0sImZpbGUiOiJDOi9Vc2Vycy9BbWl0aCBVIE5heWFrLy5nZW1pbmkvYW50aWdyYXZpdHkvc2NyYXRjaC9vcHNnZW5pZWFpL2NsaWVudC9zcmMvY29udGV4dC9BdXRoQ29udGV4dC5qc3gifQ==