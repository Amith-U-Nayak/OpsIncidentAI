import {
  require_react
} from "/node_modules/.vite/deps/chunk-RLJ2RCJQ.js?v=29a72224";
import "/node_modules/.vite/deps/chunk-DC5AMYBS.js?v=29a72224";
export default require_react();
//# sourceMappingURL=react.js.map
