import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1aa83cf1"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { BrowserRouter, Routes, Route, Navigate } from "/node_modules/.vite/deps/react-router-dom.js?v=3fc0a56c";
import { AuthProvider } from "/src/context/AuthContext.jsx";
import { SocketProvider } from "/src/context/SocketContext.jsx";
import ProtectedRoute from "/src/components/ProtectedRoute.jsx";
import Sidebar from "/src/components/Sidebar.jsx";
import Login from "/src/pages/Login.jsx";
import Register from "/src/pages/Register.jsx";
import Dashboard from "/src/pages/Dashboard.jsx";
import Incidents from "/src/pages/Incidents.jsx";
import NewIncident from "/src/pages/NewIncident.jsx";
import IncidentDetail from "/src/pages/IncidentDetail.jsx";
import Runbooks from "/src/pages/Runbooks.jsx";
const AppLayout = ({ children }) => /* @__PURE__ */ jsxDEV("div", { className: "flex bg-slate-900 min-h-screen", children: [
  /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
    fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
    lineNumber: 37,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("main", { className: "flex-1 ml-64 p-8 overflow-auto", children }, void 0, false, {
    fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
    lineNumber: 38,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
  lineNumber: 36,
  columnNumber: 1
}, this);
_c = AppLayout;
function App() {
  return /* @__PURE__ */ jsxDEV(BrowserRouter, { children: /* @__PURE__ */ jsxDEV(AuthProvider, { children: /* @__PURE__ */ jsxDEV(SocketProvider, { children: /* @__PURE__ */ jsxDEV(Routes, { children: [
    /* @__PURE__ */ jsxDEV(Route, { path: "/login", element: /* @__PURE__ */ jsxDEV(Login, {}, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
      lineNumber: 51,
      columnNumber: 43
    }, this) }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
      lineNumber: 51,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/register", element: /* @__PURE__ */ jsxDEV(Register, {}, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
      lineNumber: 52,
      columnNumber: 46
    }, this) }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
      lineNumber: 52,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/", element: /* @__PURE__ */ jsxDEV(Navigate, { to: "/dashboard", replace: true }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
      lineNumber: 53,
      columnNumber: 38
    }, this) }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
      lineNumber: 53,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/dashboard", element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(AppLayout, { children: /* @__PURE__ */ jsxDEV(Dashboard, {}, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
      lineNumber: 58,
      columnNumber: 28
    }, this) }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
      lineNumber: 58,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
      lineNumber: 57,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
      lineNumber: 56,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/incidents", element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(AppLayout, { children: /* @__PURE__ */ jsxDEV(Incidents, {}, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
      lineNumber: 63,
      columnNumber: 28
    }, this) }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
      lineNumber: 63,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
      lineNumber: 62,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
      lineNumber: 61,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/incidents/new", element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(AppLayout, { children: /* @__PURE__ */ jsxDEV(NewIncident, {}, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
      lineNumber: 68,
      columnNumber: 28
    }, this) }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
      lineNumber: 68,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
      lineNumber: 67,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
      lineNumber: 66,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/incidents/:id", element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(AppLayout, { children: /* @__PURE__ */ jsxDEV(IncidentDetail, {}, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
      lineNumber: 73,
      columnNumber: 28
    }, this) }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
      lineNumber: 73,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
      lineNumber: 72,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
      lineNumber: 71,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { path: "/runbooks", element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(AppLayout, { children: /* @__PURE__ */ jsxDEV(Runbooks, {}, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
      lineNumber: 78,
      columnNumber: 28
    }, this) }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
      lineNumber: 78,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
      lineNumber: 77,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
      lineNumber: 76,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
    lineNumber: 49,
    columnNumber: 11
  }, this) }, void 0, false, {
    fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
    lineNumber: 48,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
    lineNumber: 47,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx",
    lineNumber: 46,
    columnNumber: 5
  }, this);
}
_c2 = App;
export default App;
var _c, _c2;
$RefreshReg$(_c, "AppLayout");
$RefreshReg$(_c2, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJJOzs7Ozs7Ozs7Ozs7Ozs7O0FBakJKLFNBQVNBLGVBQWVDLFFBQVFDLE9BQU9DLGdCQUFnQjtBQUN2RCxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0Msc0JBQXNCO0FBQy9CLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxhQUFhO0FBRXBCLE9BQU9DLFdBQVc7QUFDbEIsT0FBT0MsY0FBYztBQUNyQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxjQUFjO0FBR3JCLE1BQU1DLFlBQVlBLENBQUMsRUFBRUMsU0FBUyxNQUM1Qix1QkFBQyxTQUFJLFdBQVUsa0NBQ2I7QUFBQSx5QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBUTtBQUFBLEVBQ1IsdUJBQUMsVUFBSyxXQUFVLGtDQUNiQSxZQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQTtBQUFBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUtBO0FBQ0FDLEtBUElGO0FBU04sU0FBU0csTUFBTTtBQUNiLFNBQ0UsdUJBQUMsaUJBQ0MsaUNBQUMsZ0JBQ0MsaUNBQUMsa0JBQ0MsaUNBQUMsVUFFQztBQUFBLDJCQUFDLFNBQU0sTUFBSyxVQUFTLFNBQVMsdUJBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU0sS0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3QztBQUFBLElBQ3hDLHVCQUFDLFNBQU0sTUFBSyxhQUFZLFNBQVMsdUJBQUMsY0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVMsS0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4QztBQUFBLElBQzlDLHVCQUFDLFNBQU0sTUFBSyxLQUFJLFNBQVMsdUJBQUMsWUFBUyxJQUFHLGNBQWEsU0FBTyxRQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlDLEtBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEQ7QUFBQSxJQUc5RCx1QkFBQyxTQUFNLE1BQUssY0FBYSxTQUN2Qix1QkFBQyxrQkFDQyxpQ0FBQyxhQUFVLGlDQUFDLGVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFVLEtBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0IsS0FEMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlDO0FBQUEsSUFDRCx1QkFBQyxTQUFNLE1BQUssY0FBYSxTQUN2Qix1QkFBQyxrQkFDQyxpQ0FBQyxhQUFVLGlDQUFDLGVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFVLEtBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0IsS0FEMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlDO0FBQUEsSUFDRCx1QkFBQyxTQUFNLE1BQUssa0JBQWlCLFNBQzNCLHVCQUFDLGtCQUNDLGlDQUFDLGFBQVUsaUNBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFZLEtBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEIsS0FENUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlDO0FBQUEsSUFDRCx1QkFBQyxTQUFNLE1BQUssa0JBQWlCLFNBQzNCLHVCQUFDLGtCQUNDLGlDQUFDLGFBQVUsaUNBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlLEtBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkIsS0FEL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlDO0FBQUEsSUFDRCx1QkFBQyxTQUFNLE1BQUssYUFBWSxTQUN0Qix1QkFBQyxrQkFDQyxpQ0FBQyxhQUFVLGlDQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFTLEtBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUIsS0FEekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlDO0FBQUEsT0EvQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdDQSxLQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0NBLEtBbkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvQ0EsS0FyQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNDQTtBQUVKO0FBQUNDLE1BMUNRRDtBQTRDVCxlQUFlQTtBQUFJLElBQUFELElBQUFFO0FBQUEsYUFBQUYsSUFBQTtBQUFBLGFBQUFFLEtBQUEiLCJuYW1lcyI6WyJCcm93c2VyUm91dGVyIiwiUm91dGVzIiwiUm91dGUiLCJOYXZpZ2F0ZSIsIkF1dGhQcm92aWRlciIsIlNvY2tldFByb3ZpZGVyIiwiUHJvdGVjdGVkUm91dGUiLCJTaWRlYmFyIiwiTG9naW4iLCJSZWdpc3RlciIsIkRhc2hib2FyZCIsIkluY2lkZW50cyIsIk5ld0luY2lkZW50IiwiSW5jaWRlbnREZXRhaWwiLCJSdW5ib29rcyIsIkFwcExheW91dCIsImNoaWxkcmVuIiwiX2MiLCJBcHAiLCJfYzIiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQXBwLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCcm93c2VyUm91dGVyLCBSb3V0ZXMsIFJvdXRlLCBOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgQXV0aFByb3ZpZGVyIH0gZnJvbSAnLi9jb250ZXh0L0F1dGhDb250ZXh0JztcbmltcG9ydCB7IFNvY2tldFByb3ZpZGVyIH0gZnJvbSAnLi9jb250ZXh0L1NvY2tldENvbnRleHQnO1xuaW1wb3J0IFByb3RlY3RlZFJvdXRlIGZyb20gJy4vY29tcG9uZW50cy9Qcm90ZWN0ZWRSb3V0ZSc7XG5pbXBvcnQgU2lkZWJhciBmcm9tICcuL2NvbXBvbmVudHMvU2lkZWJhcic7XG5cbmltcG9ydCBMb2dpbiBmcm9tICcuL3BhZ2VzL0xvZ2luJztcbmltcG9ydCBSZWdpc3RlciBmcm9tICcuL3BhZ2VzL1JlZ2lzdGVyJztcbmltcG9ydCBEYXNoYm9hcmQgZnJvbSAnLi9wYWdlcy9EYXNoYm9hcmQnO1xuaW1wb3J0IEluY2lkZW50cyBmcm9tICcuL3BhZ2VzL0luY2lkZW50cyc7XG5pbXBvcnQgTmV3SW5jaWRlbnQgZnJvbSAnLi9wYWdlcy9OZXdJbmNpZGVudCc7XG5pbXBvcnQgSW5jaWRlbnREZXRhaWwgZnJvbSAnLi9wYWdlcy9JbmNpZGVudERldGFpbCc7XG5pbXBvcnQgUnVuYm9va3MgZnJvbSAnLi9wYWdlcy9SdW5ib29rcyc7XG5cbi8vIExheW91dCB3cmFwcGVyIOKAlCBhZGRzIHRoZSBzaWRlYmFyIHRvIGFsbCBwcm90ZWN0ZWQgcGFnZXNcbmNvbnN0IEFwcExheW91dCA9ICh7IGNoaWxkcmVuIH0pID0+IChcbiAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGJnLXNsYXRlLTkwMCBtaW4taC1zY3JlZW5cIj5cbiAgICA8U2lkZWJhciAvPlxuICAgIDxtYWluIGNsYXNzTmFtZT1cImZsZXgtMSBtbC02NCBwLTggb3ZlcmZsb3ctYXV0b1wiPlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvbWFpbj5cbiAgPC9kaXY+XG4pO1xuXG5mdW5jdGlvbiBBcHAoKSB7XG4gIHJldHVybiAoXG4gICAgPEJyb3dzZXJSb3V0ZXI+XG4gICAgICA8QXV0aFByb3ZpZGVyPlxuICAgICAgICA8U29ja2V0UHJvdmlkZXI+XG4gICAgICAgICAgPFJvdXRlcz5cbiAgICAgICAgICAgIHsvKiBQdWJsaWMgcm91dGVzICovfVxuICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvbG9naW5cIiBlbGVtZW50PXs8TG9naW4gLz59IC8+XG4gICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9yZWdpc3RlclwiIGVsZW1lbnQ9ezxSZWdpc3RlciAvPn0gLz5cbiAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL1wiIGVsZW1lbnQ9ezxOYXZpZ2F0ZSB0bz1cIi9kYXNoYm9hcmRcIiByZXBsYWNlIC8+fSAvPlxuXG4gICAgICAgICAgICB7LyogUHJvdGVjdGVkIHJvdXRlcyDigJQgcmVxdWlyZSBsb2dpbiAqL31cbiAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL2Rhc2hib2FyZFwiIGVsZW1lbnQ9e1xuICAgICAgICAgICAgICA8UHJvdGVjdGVkUm91dGU+XG4gICAgICAgICAgICAgICAgPEFwcExheW91dD48RGFzaGJvYXJkIC8+PC9BcHBMYXlvdXQ+XG4gICAgICAgICAgICAgIDwvUHJvdGVjdGVkUm91dGU+XG4gICAgICAgICAgICB9IC8+XG4gICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9pbmNpZGVudHNcIiBlbGVtZW50PXtcbiAgICAgICAgICAgICAgPFByb3RlY3RlZFJvdXRlPlxuICAgICAgICAgICAgICAgIDxBcHBMYXlvdXQ+PEluY2lkZW50cyAvPjwvQXBwTGF5b3V0PlxuICAgICAgICAgICAgICA8L1Byb3RlY3RlZFJvdXRlPlxuICAgICAgICAgICAgfSAvPlxuICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvaW5jaWRlbnRzL25ld1wiIGVsZW1lbnQ9e1xuICAgICAgICAgICAgICA8UHJvdGVjdGVkUm91dGU+XG4gICAgICAgICAgICAgICAgPEFwcExheW91dD48TmV3SW5jaWRlbnQgLz48L0FwcExheW91dD5cbiAgICAgICAgICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cbiAgICAgICAgICAgIH0gLz5cbiAgICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL2luY2lkZW50cy86aWRcIiBlbGVtZW50PXtcbiAgICAgICAgICAgICAgPFByb3RlY3RlZFJvdXRlPlxuICAgICAgICAgICAgICAgIDxBcHBMYXlvdXQ+PEluY2lkZW50RGV0YWlsIC8+PC9BcHBMYXlvdXQ+XG4gICAgICAgICAgICAgIDwvUHJvdGVjdGVkUm91dGU+XG4gICAgICAgICAgICB9IC8+XG4gICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9ydW5ib29rc1wiIGVsZW1lbnQ9e1xuICAgICAgICAgICAgICA8UHJvdGVjdGVkUm91dGU+XG4gICAgICAgICAgICAgICAgPEFwcExheW91dD48UnVuYm9va3MgLz48L0FwcExheW91dD5cbiAgICAgICAgICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cbiAgICAgICAgICAgIH0gLz5cbiAgICAgICAgICA8L1JvdXRlcz5cbiAgICAgICAgPC9Tb2NrZXRQcm92aWRlcj5cbiAgICAgIDwvQXV0aFByb3ZpZGVyPlxuICAgIDwvQnJvd3NlclJvdXRlcj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwO1xuIl0sImZpbGUiOiJDOi9Vc2Vycy9BbWl0aCBVIE5heWFrLy5nZW1pbmkvYW50aWdyYXZpdHkvc2NyYXRjaC9vcHNnZW5pZWFpL2NsaWVudC9zcmMvQXBwLmpzeCJ9