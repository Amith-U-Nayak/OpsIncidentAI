import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/context/SocketContext.jsx");import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false, "VITE_API_URL": "http://localhost:5000/api", "VITE_SOCKET_URL": "http://localhost:5000"};import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1aa83cf1"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/context/SocketContext.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=1aa83cf1"; const createContext = __vite__cjsImport3_react["createContext"]; const useContext = __vite__cjsImport3_react["useContext"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { io } from "/node_modules/.vite/deps/socket__io-client.js?v=b70d166e";
import { useAuth } from "/src/context/AuthContext.jsx";
const SocketContext = createContext(null);
export const SocketProvider = ({ children }) => {
  _s();
  const [socket, setSocket] = useState(null);
  const { token } = useAuth();
  useEffect(() => {
    if (!token) return;
    const newSocket = io(import.meta.env.VITE_SOCKET_URL, {
      transports: ["websocket"]
    });
    newSocket.on("connect", () => {
      console.log("🔌 Socket connected:", newSocket.id);
    });
    setSocket(newSocket);
    return () => newSocket.disconnect();
  }, [token]);
  return /* @__PURE__ */ jsxDEV(SocketContext.Provider, { value: socket, children }, void 0, false, {
    fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/context/SocketContext.jsx",
    lineNumber: 49,
    columnNumber: 5
  }, this);
};
_s(SocketProvider, "cX1NoXXNdzBBdjZ6kOdKxWMQlJQ=", false, function() {
  return [useAuth];
});
_c = SocketProvider;
export const useSocket = () => {
  _s2();
  return useContext(SocketContext);
};
_s2(useSocket, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
var _c;
$RefreshReg$(_c, "SocketProvider");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/context/SocketContext.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/context/SocketContext.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkJJOzs7Ozs7Ozs7Ozs7Ozs7OztBQTdCSixTQUFTQSxlQUFlQyxZQUFZQyxXQUFXQyxnQkFBZ0I7QUFDL0QsU0FBU0MsVUFBVTtBQUNuQixTQUFTQyxlQUFlO0FBRXhCLE1BQU1DLGdCQUFnQk4sY0FBYyxJQUFJO0FBRWpDLGFBQU1PLGlCQUFpQkEsQ0FBQyxFQUFFQyxTQUFTLE1BQU07QUFBQUMsS0FBQTtBQUM5QyxRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSVIsU0FBUyxJQUFJO0FBQ3pDLFFBQU0sRUFBRVMsTUFBTSxJQUFJUCxRQUFRO0FBRTFCSCxZQUFVLE1BQU07QUFDZCxRQUFJLENBQUNVLE1BQU87QUFHWixVQUFNQyxZQUFZVCxHQUFHVSxZQUFZQyxJQUFJQyxpQkFBaUI7QUFBQSxNQUNwREMsWUFBWSxDQUFDLFdBQVc7QUFBQSxJQUMxQixDQUFDO0FBRURKLGNBQVVLLEdBQUcsV0FBVyxNQUFNO0FBQzVCQyxjQUFRQyxJQUFJLHdCQUF3QlAsVUFBVVEsRUFBRTtBQUFBLElBQ2xELENBQUM7QUFFRFYsY0FBVUUsU0FBUztBQUduQixXQUFPLE1BQU1BLFVBQVVTLFdBQVc7QUFBQSxFQUNwQyxHQUFHLENBQUNWLEtBQUssQ0FBQztBQUVWLFNBQ0UsdUJBQUMsY0FBYyxVQUFkLEVBQXVCLE9BQU9GLFFBQzVCRixZQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQTtBQUVKO0FBQUVDLEdBM0JXRixnQkFBYztBQUFBLFVBRVBGLE9BQU87QUFBQTtBQUFBLEtBRmRFO0FBNkJOLGFBQU1nQixZQUFZQSxNQUFBO0FBQUFDLE1BQUE7QUFBQSxTQUFNdkIsV0FBV0ssYUFBYTtBQUFDO0FBQUNrQixJQUE1Q0QsV0FBUztBQUFBLElBQUFFO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbImNyZWF0ZUNvbnRleHQiLCJ1c2VDb250ZXh0IiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJpbyIsInVzZUF1dGgiLCJTb2NrZXRDb250ZXh0IiwiU29ja2V0UHJvdmlkZXIiLCJjaGlsZHJlbiIsIl9zIiwic29ja2V0Iiwic2V0U29ja2V0IiwidG9rZW4iLCJuZXdTb2NrZXQiLCJpbXBvcnQiLCJlbnYiLCJWSVRFX1NPQ0tFVF9VUkwiLCJ0cmFuc3BvcnRzIiwib24iLCJjb25zb2xlIiwibG9nIiwiaWQiLCJkaXNjb25uZWN0IiwidXNlU29ja2V0IiwiX3MyIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU29ja2V0Q29udGV4dC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlQ29udGV4dCwgdXNlQ29udGV4dCwgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGlvIH0gZnJvbSAnc29ja2V0LmlvLWNsaWVudCc7XG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi9BdXRoQ29udGV4dCc7XG5cbmNvbnN0IFNvY2tldENvbnRleHQgPSBjcmVhdGVDb250ZXh0KG51bGwpO1xuXG5leHBvcnQgY29uc3QgU29ja2V0UHJvdmlkZXIgPSAoeyBjaGlsZHJlbiB9KSA9PiB7XG4gIGNvbnN0IFtzb2NrZXQsIHNldFNvY2tldF0gPSB1c2VTdGF0ZShudWxsKTtcbiAgY29uc3QgeyB0b2tlbiB9ID0gdXNlQXV0aCgpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCF0b2tlbikgcmV0dXJuO1xuXG4gICAgLy8gQ29ubmVjdCB0byBTb2NrZXQuSU8gc2VydmVyXG4gICAgY29uc3QgbmV3U29ja2V0ID0gaW8oaW1wb3J0Lm1ldGEuZW52LlZJVEVfU09DS0VUX1VSTCwge1xuICAgICAgdHJhbnNwb3J0czogWyd3ZWJzb2NrZXQnXSxcbiAgICB9KTtcblxuICAgIG5ld1NvY2tldC5vbignY29ubmVjdCcsICgpID0+IHtcbiAgICAgIGNvbnNvbGUubG9nKCfwn5SMIFNvY2tldCBjb25uZWN0ZWQ6JywgbmV3U29ja2V0LmlkKTtcbiAgICB9KTtcblxuICAgIHNldFNvY2tldChuZXdTb2NrZXQpO1xuXG4gICAgLy8gQ2xlYW51cDogZGlzY29ubmVjdCB3aGVuIHVzZXIgbG9ncyBvdXQgb3IgY29tcG9uZW50IHVubW91bnRzXG4gICAgcmV0dXJuICgpID0+IG5ld1NvY2tldC5kaXNjb25uZWN0KCk7XG4gIH0sIFt0b2tlbl0pO1xuXG4gIHJldHVybiAoXG4gICAgPFNvY2tldENvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3NvY2tldH0+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9Tb2NrZXRDb250ZXh0LlByb3ZpZGVyPlxuICApO1xufTtcblxuZXhwb3J0IGNvbnN0IHVzZVNvY2tldCA9ICgpID0+IHVzZUNvbnRleHQoU29ja2V0Q29udGV4dCk7XG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FtaXRoIFUgTmF5YWsvLmdlbWluaS9hbnRpZ3Jhdml0eS9zY3JhdGNoL29wc2dlbmllYWkvY2xpZW50L3NyYy9jb250ZXh0L1NvY2tldENvbnRleHQuanN4In0=