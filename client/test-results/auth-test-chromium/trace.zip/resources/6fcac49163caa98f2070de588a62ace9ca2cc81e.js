import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ProtectedRoute.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1aa83cf1"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/ProtectedRoute.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Navigate } from "/node_modules/.vite/deps/react-router-dom.js?v=3fc0a56c";
import { useAuth } from "/src/context/AuthContext.jsx";
const ProtectedRoute = ({ children }) => {
  _s();
  const { user, loading } = useAuth();
  if (loading) {
    return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center h-screen bg-slate-900", children: /* @__PURE__ */ jsxDEV("div", { className: "text-indigo-400 text-xl animate-pulse", children: "Loading..." }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/ProtectedRoute.jsx",
      lineNumber: 32,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/ProtectedRoute.jsx",
      lineNumber: 31,
      columnNumber: 7
    }, this);
  }
  if (!user) return /* @__PURE__ */ jsxDEV(Navigate, { to: "/login", replace: true }, void 0, false, {
    fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/ProtectedRoute.jsx",
    lineNumber: 37,
    columnNumber: 21
  }, this);
  return children;
};
_s(ProtectedRoute, "EmJkapf7qiLC5Br5eCoEq4veZes=", false, function() {
  return [useAuth];
});
_c = ProtectedRoute;
export default ProtectedRoute;
var _c;
$RefreshReg$(_c, "ProtectedRoute");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/ProtectedRoute.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/ProtectedRoute.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWVE7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBWlIsU0FBU0EsZ0JBQWdCO0FBQ3pCLFNBQVNDLGVBQWU7QUFLeEIsTUFBTUMsaUJBQWlCQSxDQUFDLEVBQUVDLFNBQVMsTUFBTTtBQUFBQyxLQUFBO0FBQ3ZDLFFBQU0sRUFBRUMsTUFBTUMsUUFBUSxJQUFJTCxRQUFRO0FBRWxDLE1BQUlLLFNBQVM7QUFDWCxXQUNFLHVCQUFDLFNBQUksV0FBVSwwREFDYixpQ0FBQyxTQUFJLFdBQVUseUNBQXdDLDBCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlFLEtBRG5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFFQSxNQUFJLENBQUNELEtBQU0sUUFBTyx1QkFBQyxZQUFTLElBQUcsVUFBUyxTQUFPLFFBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBNkI7QUFDL0MsU0FBT0Y7QUFDVDtBQUFFQyxHQWJJRixnQkFBYztBQUFBLFVBQ1FELE9BQU87QUFBQTtBQUFBLEtBRDdCQztBQWVOLGVBQWVBO0FBQWUsSUFBQUs7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiTmF2aWdhdGUiLCJ1c2VBdXRoIiwiUHJvdGVjdGVkUm91dGUiLCJjaGlsZHJlbiIsIl9zIiwidXNlciIsImxvYWRpbmciLCJfYyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQcm90ZWN0ZWRSb3V0ZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuLi9jb250ZXh0L0F1dGhDb250ZXh0JztcblxuLy8gUHJvdGVjdGVkUm91dGUg4oCUIGxpa2UgYSBzZWN1cml0eSBndWFyZCBhdCB0aGUgZG9vclxuLy8gSWYgdXNlciBpcyBub3QgbG9nZ2VkIGluLCByZWRpcmVjdCB0aGVtIHRvIC9sb2dpblxuLy8gSWYgbG9nZ2VkIGluLCBzaG93IHRoZSByZXF1ZXN0ZWQgcGFnZVxuY29uc3QgUHJvdGVjdGVkUm91dGUgPSAoeyBjaGlsZHJlbiB9KSA9PiB7XG4gIGNvbnN0IHsgdXNlciwgbG9hZGluZyB9ID0gdXNlQXV0aCgpO1xuXG4gIGlmIChsb2FkaW5nKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgaC1zY3JlZW4gYmctc2xhdGUtOTAwXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1pbmRpZ28tNDAwIHRleHQteGwgYW5pbWF0ZS1wdWxzZVwiPkxvYWRpbmcuLi48L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cblxuICBpZiAoIXVzZXIpIHJldHVybiA8TmF2aWdhdGUgdG89XCIvbG9naW5cIiByZXBsYWNlIC8+O1xuICByZXR1cm4gY2hpbGRyZW47XG59O1xuXG5leHBvcnQgZGVmYXVsdCBQcm90ZWN0ZWRSb3V0ZTtcbiJdLCJmaWxlIjoiQzovVXNlcnMvQW1pdGggVSBOYXlhay8uZ2VtaW5pL2FudGlncmF2aXR5L3NjcmF0Y2gvb3BzZ2VuaWVhaS9jbGllbnQvc3JjL2NvbXBvbmVudHMvUHJvdGVjdGVkUm91dGUuanN4In0=