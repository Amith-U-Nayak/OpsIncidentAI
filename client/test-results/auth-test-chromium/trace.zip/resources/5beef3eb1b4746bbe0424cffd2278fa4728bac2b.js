import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/NewIncident.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1aa83cf1"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=1aa83cf1"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=3fc0a56c";
import api from "/src/api/axios.js";
import { useSocket } from "/src/context/SocketContext.jsx";
import AgentStepper from "/src/components/AgentStepper.jsx";
const NewIncident = () => {
  _s();
  const [form, setForm] = useState({ title: "", description: "", severity: "Medium" });
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [incidentId, setIncidentId] = useState(null);
  const [agentEvents, setAgentEvents] = useState([]);
  const [pipelineComplete, setPipelineComplete] = useState(false);
  const navigate = useNavigate();
  const socket = useSocket();
  useEffect(() => {
    if (!socket || !incidentId) return;
    const handleAgentUpdate = (data) => {
      if (data.incidentId !== incidentId) return;
      setAgentEvents((prev) => [...prev, data]);
      if (data.agent === "postMortemGenerator" && data.status === "done") {
        setPipelineComplete(true);
      }
    };
    socket.on("agent_update", handleAgentUpdate);
    return () => {
      socket.off("agent_update", handleAgentUpdate);
    };
  }, [socket, incidentId]);
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const formData = new FormData();
      formData.append("title", form.title);
      formData.append("description", form.description);
      formData.append("severity", form.severity);
      if (file) formData.append("logs", file);
      const createRes = await api.post("/incidents", formData, {
        headers: { "Content-Type": "multipart/form-data" }
      });
      const newIncidentId = createRes.data.data._id;
      setIncidentId(newIncidentId);
      api.post(`/incidents/${newIncidentId}/analyse`).catch((err) => {
        console.error("Pipeline error:", err);
        setError("AI Pipeline failed to run.");
      });
    } catch (err) {
      setError(err.response?.data?.error || "Failed to create incident");
      setLoading(false);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "max-w-4xl mx-auto space-y-6", children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-white", children: "Report New Incident" }, void 0, false, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
        lineNumber: 103,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-slate-400 text-sm", children: "Upload logs and let AI analyze the root cause" }, void 0, false, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
        lineNumber: 104,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
      lineNumber: 102,
      columnNumber: 7
    }, this),
    error && /* @__PURE__ */ jsxDEV("div", { className: "bg-red-500/10 border border-red-500 text-red-400 p-4 rounded-lg", children: error }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
      lineNumber: 108,
      columnNumber: 7
    }, this),
    incidentId ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-6 fade-in", children: [
      /* @__PURE__ */ jsxDEV(AgentStepper, { events: agentEvents }, void 0, false, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
        lineNumber: 116,
        columnNumber: 11
      }, this),
      pipelineComplete && /* @__PURE__ */ jsxDEV("div", { className: "bg-green-500/10 border border-green-500/30 p-6 rounded-xl flex items-center justify-between", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-green-400 font-bold text-lg", children: "Analysis Complete!" }, void 0, false, {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
            lineNumber: 121,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-green-500/80 text-sm mt-1", children: "The AI has generated a post-mortem and runbook solution." }, void 0, false, {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
            lineNumber: 122,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
          lineNumber: 120,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => navigate(`/incidents/${incidentId}`),
            className: "bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-medium transition-colors",
            children: "View Full Report →"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
            lineNumber: 124,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
        lineNumber: 119,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
      lineNumber: 115,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "bg-slate-800 rounded-xl p-8 border border-slate-700 space-y-6", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "text-slate-400 text-sm mb-1 block font-medium", children: "Incident Title" }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
          lineNumber: 136,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            required: true,
            value: form.title,
            onChange: (e) => setForm({ ...form, title: e.target.value }),
            className: "w-full bg-slate-900 border border-slate-600 text-white rounded-lg px-4 py-3 focus:outline-none focus:border-indigo-500",
            placeholder: "e.g., Database Connection Timeout in Production"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
            lineNumber: 137,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
        lineNumber: 135,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "text-slate-400 text-sm mb-1 block font-medium", children: "Description" }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
          lineNumber: 148,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "textarea",
          {
            required: true,
            rows: "4",
            value: form.description,
            onChange: (e) => setForm({ ...form, description: e.target.value }),
            className: "w-full bg-slate-900 border border-slate-600 text-white rounded-lg px-4 py-3 focus:outline-none focus:border-indigo-500",
            placeholder: "Describe what happened, when it started, and user impact..."
          },
          void 0,
          false,
          {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
            lineNumber: 149,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
        lineNumber: 147,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-slate-400 text-sm mb-1 block font-medium", children: "Severity" }, void 0, false, {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
            lineNumber: 161,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              value: form.severity,
              onChange: (e) => setForm({ ...form, severity: e.target.value }),
              className: "w-full bg-slate-900 border border-slate-600 text-white rounded-lg px-4 py-3 focus:outline-none focus:border-indigo-500",
              children: [
                /* @__PURE__ */ jsxDEV("option", { value: "Low", children: "Low" }, void 0, false, {
                  fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
                  lineNumber: 167,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "Medium", children: "Medium" }, void 0, false, {
                  fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
                  lineNumber: 168,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "High", children: "High" }, void 0, false, {
                  fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
                  lineNumber: 169,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "Critical", children: "Critical" }, void 0, false, {
                  fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
                  lineNumber: 170,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
              lineNumber: 162,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
          lineNumber: 160,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-slate-400 text-sm mb-1 block font-medium", children: "Attach Log File" }, void 0, false, {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
            lineNumber: 175,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "file",
              onChange: (e) => setFile(e.target.files[0]),
              className: "w-full bg-slate-900 border border-slate-600 text-slate-400 rounded-lg px-4 py-2.5 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-500/10 file:text-indigo-400 hover:file:bg-indigo-500/20 cursor-pointer"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
              lineNumber: 176,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
          lineNumber: 174,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
        lineNumber: 159,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "pt-4 border-t border-slate-700 flex justify-end", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => navigate("/incidents"),
            className: "px-6 py-3 text-slate-400 hover:text-white font-medium mr-4",
            children: "Cancel"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
            lineNumber: 185,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "submit",
            disabled: loading,
            className: "bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-700 disabled:text-slate-500 text-white px-8 py-3 rounded-lg font-medium transition-colors shadow-lg flex items-center gap-2",
            children: loading ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV("span", { className: "animate-spin text-lg", children: "⏳" }, void 0, false, {
                fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
                lineNumber: 199,
                columnNumber: 19
              }, this),
              " Uploading..."
            ] }, void 0, true, {
              fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
              lineNumber: 198,
              columnNumber: 13
            }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: "🚀 Submit & Run AI" }, void 0, false, {
              fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
              lineNumber: 202,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
            lineNumber: 192,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
        lineNumber: 184,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
      lineNumber: 134,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx",
    lineNumber: 101,
    columnNumber: 5
  }, this);
};
_s(NewIncident, "2bxVzcShyzysoCakihNf1KukjuY=", false, function() {
  return [useNavigate, useSocket];
});
_c = NewIncident;
export default NewIncident;
var _c;
$RefreshReg$(_c, "NewIncident");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/NewIncident.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUZRLFNBK0ZRLFVBL0ZSOzs7Ozs7Ozs7Ozs7Ozs7OztBQW5GUixTQUFTQSxVQUFVQyxpQkFBaUI7QUFDcEMsU0FBU0MsbUJBQW1CO0FBQzVCLE9BQU9DLFNBQVM7QUFDaEIsU0FBU0MsaUJBQWlCO0FBQzFCLE9BQU9DLGtCQUFrQjtBQUV6QixNQUFNQyxjQUFjQSxNQUFNO0FBQUFDLEtBQUE7QUFDeEIsUUFBTSxDQUFDQyxNQUFNQyxPQUFPLElBQUlULFNBQVMsRUFBRVUsT0FBTyxJQUFJQyxhQUFhLElBQUlDLFVBQVUsU0FBUyxDQUFDO0FBQ25GLFFBQU0sQ0FBQ0MsTUFBTUMsT0FBTyxJQUFJZCxTQUFTLElBQUk7QUFDckMsUUFBTSxDQUFDZSxTQUFTQyxVQUFVLElBQUloQixTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDaUIsT0FBT0MsUUFBUSxJQUFJbEIsU0FBUyxFQUFFO0FBR3JDLFFBQU0sQ0FBQ21CLFlBQVlDLGFBQWEsSUFBSXBCLFNBQVMsSUFBSTtBQUNqRCxRQUFNLENBQUNxQixhQUFhQyxjQUFjLElBQUl0QixTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDdUIsa0JBQWtCQyxtQkFBbUIsSUFBSXhCLFNBQVMsS0FBSztBQUU5RCxRQUFNeUIsV0FBV3ZCLFlBQVk7QUFDN0IsUUFBTXdCLFNBQVN0QixVQUFVO0FBSXpCSCxZQUFVLE1BQU07QUFDZCxRQUFJLENBQUN5QixVQUFVLENBQUNQLFdBQVk7QUFFNUIsVUFBTVEsb0JBQW9CQSxDQUFDQyxTQUFTO0FBRWxDLFVBQUlBLEtBQUtULGVBQWVBLFdBQVk7QUFHcENHLHFCQUFlLENBQUNPLFNBQVMsQ0FBQyxHQUFHQSxNQUFNRCxJQUFJLENBQUM7QUFHeEMsVUFBSUEsS0FBS0UsVUFBVSx5QkFBeUJGLEtBQUtHLFdBQVcsUUFBUTtBQUNsRVAsNEJBQW9CLElBQUk7QUFBQSxNQUMxQjtBQUFBLElBQ0Y7QUFHQUUsV0FBT00sR0FBRyxnQkFBZ0JMLGlCQUFpQjtBQUUzQyxXQUFPLE1BQU07QUFDWEQsYUFBT08sSUFBSSxnQkFBZ0JOLGlCQUFpQjtBQUFBLElBQzlDO0FBQUEsRUFDRixHQUFHLENBQUNELFFBQVFQLFVBQVUsQ0FBQztBQUV2QixRQUFNZSxlQUFlLE9BQU9DLE1BQU07QUFDaENBLE1BQUVDLGVBQWU7QUFDakJsQixhQUFTLEVBQUU7QUFDWEYsZUFBVyxJQUFJO0FBRWYsUUFBSTtBQUVGLFlBQU1xQixXQUFXLElBQUlDLFNBQVM7QUFDOUJELGVBQVNFLE9BQU8sU0FBUy9CLEtBQUtFLEtBQUs7QUFDbkMyQixlQUFTRSxPQUFPLGVBQWUvQixLQUFLRyxXQUFXO0FBQy9DMEIsZUFBU0UsT0FBTyxZQUFZL0IsS0FBS0ksUUFBUTtBQUN6QyxVQUFJQyxLQUFNd0IsVUFBU0UsT0FBTyxRQUFRMUIsSUFBSTtBQUd0QyxZQUFNMkIsWUFBWSxNQUFNckMsSUFBSXNDLEtBQUssY0FBY0osVUFBVTtBQUFBLFFBQ3ZESyxTQUFTLEVBQUUsZ0JBQWdCLHNCQUFzQjtBQUFBLE1BQ25ELENBQUM7QUFFRCxZQUFNQyxnQkFBZ0JILFVBQVVaLEtBQUtBLEtBQUtnQjtBQUMxQ3hCLG9CQUFjdUIsYUFBYTtBQUkzQnhDLFVBQUlzQyxLQUFLLGNBQWNFLGFBQWEsVUFBVSxFQUFFRSxNQUFNLENBQUFDLFFBQU87QUFDM0RDLGdCQUFROUIsTUFBTSxtQkFBbUI2QixHQUFHO0FBQ3BDNUIsaUJBQVMsNEJBQTRCO0FBQUEsTUFDdkMsQ0FBQztBQUFBLElBRUgsU0FBUzRCLEtBQUs7QUFDWjVCLGVBQVM0QixJQUFJRSxVQUFVcEIsTUFBTVgsU0FBUywyQkFBMkI7QUFDakVELGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLDJCQUFDLFNBQ0M7QUFBQSw2QkFBQyxRQUFHLFdBQVUsaUNBQWdDLG1DQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlFO0FBQUEsTUFDakUsdUJBQUMsT0FBRSxXQUFVLDBCQUF5Qiw2REFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRjtBQUFBLFNBRnJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBRUNDLFNBQ0MsdUJBQUMsU0FBSSxXQUFVLG1FQUNaQSxtQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUlERSxhQUNDLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLDZCQUFDLGdCQUFhLFFBQVFFLGVBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0M7QUFBQSxNQUVqQ0Usb0JBQ0MsdUJBQUMsU0FBSSxXQUFVLCtGQUNiO0FBQUEsK0JBQUMsU0FDQztBQUFBLGlDQUFDLFFBQUcsV0FBVSxvQ0FBbUMsa0NBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1FO0FBQUEsVUFDbkUsdUJBQUMsT0FBRSxXQUFVLGtDQUFpQyx3RUFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0c7QUFBQSxhQUZ4RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU1FLFNBQVMsY0FBY04sVUFBVSxFQUFFO0FBQUEsWUFDbEQsV0FBVTtBQUFBLFlBQStGO0FBQUE7QUFBQSxVQUYzRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFdBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsU0FmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUJBLElBRUEsdUJBQUMsVUFBSyxVQUFVZSxjQUFjLFdBQVUsaUVBQ3RDO0FBQUEsNkJBQUMsU0FDQztBQUFBLCtCQUFDLFdBQU0sV0FBVSxpREFBZ0QsOEJBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0U7QUFBQSxRQUMvRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0w7QUFBQSxZQUNBLE9BQU8xQixLQUFLRTtBQUFBQSxZQUNaLFVBQVUsQ0FBQ3lCLE1BQU0xQixRQUFRLEVBQUUsR0FBR0QsTUFBTUUsT0FBT3lCLEVBQUVjLE9BQU9DLE1BQU0sQ0FBQztBQUFBLFlBQzNELFdBQVU7QUFBQSxZQUNWLGFBQVk7QUFBQTtBQUFBLFVBTmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTStEO0FBQUEsV0FSakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsTUFFQSx1QkFBQyxTQUNDO0FBQUEsK0JBQUMsV0FBTSxXQUFVLGlEQUFnRCwyQkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RTtBQUFBLFFBQzVFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQztBQUFBLFlBQ0EsTUFBSztBQUFBLFlBQ0wsT0FBTzFDLEtBQUtHO0FBQUFBLFlBQ1osVUFBVSxDQUFDd0IsTUFBTTFCLFFBQVEsRUFBRSxHQUFHRCxNQUFNRyxhQUFhd0IsRUFBRWMsT0FBT0MsTUFBTSxDQUFDO0FBQUEsWUFDakUsV0FBVTtBQUFBLFlBQ1YsYUFBWTtBQUFBO0FBQUEsVUFOZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNMkU7QUFBQSxXQVI3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLCtCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsaURBQWdELHdCQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RTtBQUFBLFVBQ3pFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFPMUMsS0FBS0k7QUFBQUEsY0FDWixVQUFVLENBQUN1QixNQUFNMUIsUUFBUSxFQUFFLEdBQUdELE1BQU1JLFVBQVV1QixFQUFFYyxPQUFPQyxNQUFNLENBQUM7QUFBQSxjQUM5RCxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFlBQU8sT0FBTSxPQUFNLG1CQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1QjtBQUFBLGdCQUN2Qix1QkFBQyxZQUFPLE9BQU0sVUFBUyxzQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkI7QUFBQSxnQkFDN0IsdUJBQUMsWUFBTyxPQUFNLFFBQU8sb0JBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlCO0FBQUEsZ0JBQ3pCLHVCQUFDLFlBQU8sT0FBTSxZQUFXLHdCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpQztBQUFBO0FBQUE7QUFBQSxZQVJuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFTQTtBQUFBLGFBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBO0FBQUEsUUFFQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGlEQUFnRCwrQkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Y7QUFBQSxVQUNoRjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsVUFBVSxDQUFDZixNQUFNckIsUUFBUXFCLEVBQUVjLE9BQU9FLE1BQU0sQ0FBQyxDQUFDO0FBQUEsY0FDMUMsV0FBVTtBQUFBO0FBQUEsWUFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFHbVI7QUFBQSxhQUxyUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxXQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUJBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsbURBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBUyxNQUFNMUIsU0FBUyxZQUFZO0FBQUEsWUFDcEMsV0FBVTtBQUFBLFlBQTREO0FBQUE7QUFBQSxVQUh4RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFVBQVVWO0FBQUFBLFlBQ1YsV0FBVTtBQUFBLFlBRVRBLG9CQUNDLG1DQUNFO0FBQUEscUNBQUMsVUFBSyxXQUFVLHdCQUF1QixpQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0M7QUFBQSxjQUFPO0FBQUEsaUJBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsSUFFQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUE7QUFBQSxVQVpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWNBO0FBQUEsV0F0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVCQTtBQUFBLFNBekVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwRUE7QUFBQSxPQTNHSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNkdBO0FBRUo7QUFBRVIsR0ExTElELGFBQVc7QUFBQSxVQVdFSixhQUNGRSxTQUFTO0FBQUE7QUFBQSxLQVpwQkU7QUE0TE4sZUFBZUE7QUFBWSxJQUFBOEM7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VOYXZpZ2F0ZSIsImFwaSIsInVzZVNvY2tldCIsIkFnZW50U3RlcHBlciIsIk5ld0luY2lkZW50IiwiX3MiLCJmb3JtIiwic2V0Rm9ybSIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJzZXZlcml0eSIsImZpbGUiLCJzZXRGaWxlIiwibG9hZGluZyIsInNldExvYWRpbmciLCJlcnJvciIsInNldEVycm9yIiwiaW5jaWRlbnRJZCIsInNldEluY2lkZW50SWQiLCJhZ2VudEV2ZW50cyIsInNldEFnZW50RXZlbnRzIiwicGlwZWxpbmVDb21wbGV0ZSIsInNldFBpcGVsaW5lQ29tcGxldGUiLCJuYXZpZ2F0ZSIsInNvY2tldCIsImhhbmRsZUFnZW50VXBkYXRlIiwiZGF0YSIsInByZXYiLCJhZ2VudCIsInN0YXR1cyIsIm9uIiwib2ZmIiwiaGFuZGxlU3VibWl0IiwiZSIsInByZXZlbnREZWZhdWx0IiwiZm9ybURhdGEiLCJGb3JtRGF0YSIsImFwcGVuZCIsImNyZWF0ZVJlcyIsInBvc3QiLCJoZWFkZXJzIiwibmV3SW5jaWRlbnRJZCIsIl9pZCIsImNhdGNoIiwiZXJyIiwiY29uc29sZSIsInJlc3BvbnNlIiwidGFyZ2V0IiwidmFsdWUiLCJmaWxlcyIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk5ld0luY2lkZW50LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCBhcGkgZnJvbSAnLi4vYXBpL2F4aW9zJztcbmltcG9ydCB7IHVzZVNvY2tldCB9IGZyb20gJy4uL2NvbnRleHQvU29ja2V0Q29udGV4dCc7XG5pbXBvcnQgQWdlbnRTdGVwcGVyIGZyb20gJy4uL2NvbXBvbmVudHMvQWdlbnRTdGVwcGVyJztcblxuY29uc3QgTmV3SW5jaWRlbnQgPSAoKSA9PiB7XG4gIGNvbnN0IFtmb3JtLCBzZXRGb3JtXSA9IHVzZVN0YXRlKHsgdGl0bGU6ICcnLCBkZXNjcmlwdGlvbjogJycsIHNldmVyaXR5OiAnTWVkaXVtJyB9KTtcbiAgY29uc3QgW2ZpbGUsIHNldEZpbGVdID0gdXNlU3RhdGUobnVsbCk7XG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJyk7XG4gIFxuICAvLyBSZWFsLXRpbWUgQUkgcGlwZWxpbmUgc3RhdGVcbiAgY29uc3QgW2luY2lkZW50SWQsIHNldEluY2lkZW50SWRdID0gdXNlU3RhdGUobnVsbCk7XG4gIGNvbnN0IFthZ2VudEV2ZW50cywgc2V0QWdlbnRFdmVudHNdID0gdXNlU3RhdGUoW10pO1xuICBjb25zdCBbcGlwZWxpbmVDb21wbGV0ZSwgc2V0UGlwZWxpbmVDb21wbGV0ZV0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIFxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gIGNvbnN0IHNvY2tldCA9IHVzZVNvY2tldCgpO1xuXG4gIC8vIEhDSSBQcmluY2lwbGU6IFZpc2liaWxpdHkgb2YgU3lzdGVtIFN0YXR1cy5cbiAgLy8gTGlzdGVuIGZvciByZWFsLXRpbWUgU29ja2V0LklPIGV2ZW50cyBmcm9tIHRoZSBiYWNrZW5kIEFJIGFnZW50c1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghc29ja2V0IHx8ICFpbmNpZGVudElkKSByZXR1cm47XG5cbiAgICBjb25zdCBoYW5kbGVBZ2VudFVwZGF0ZSA9IChkYXRhKSA9PiB7XG4gICAgICAvLyBPTkxZIHByb2Nlc3MgZXZlbnRzIGZvciB0aGlzIHNwZWNpZmljIGluY2lkZW50XG4gICAgICBpZiAoZGF0YS5pbmNpZGVudElkICE9PSBpbmNpZGVudElkKSByZXR1cm47XG5cbiAgICAgIC8vIEFkZCBuZXcgZXZlbnQgdG8gdGhlIGxpc3RcbiAgICAgIHNldEFnZW50RXZlbnRzKChwcmV2KSA9PiBbLi4ucHJldiwgZGF0YV0pO1xuICAgICAgXG4gICAgICAvLyBJZiB0aGUgbGFzdCBhZ2VudCAoUG9zdE1vcnRlbSkgaXMgZG9uZSwgcGlwZWxpbmUgaXMgZmluaXNoZWRcbiAgICAgIGlmIChkYXRhLmFnZW50ID09PSAncG9zdE1vcnRlbUdlbmVyYXRvcicgJiYgZGF0YS5zdGF0dXMgPT09ICdkb25lJykge1xuICAgICAgICBzZXRQaXBlbGluZUNvbXBsZXRlKHRydWUpO1xuICAgICAgfVxuICAgIH07XG5cbiAgICAvLyBMaXN0ZW4gdG8gdGhlIGdlbmVyaWMgJ2FnZW50X3VwZGF0ZScgZXZlbnQgZnJvbSB0aGUgc2VydmVyXG4gICAgc29ja2V0Lm9uKCdhZ2VudF91cGRhdGUnLCBoYW5kbGVBZ2VudFVwZGF0ZSk7XG5cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgc29ja2V0Lm9mZignYWdlbnRfdXBkYXRlJywgaGFuZGxlQWdlbnRVcGRhdGUpO1xuICAgIH07XG4gIH0sIFtzb2NrZXQsIGluY2lkZW50SWRdKTtcblxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBzZXRFcnJvcignJyk7XG4gICAgc2V0TG9hZGluZyh0cnVlKTtcblxuICAgIHRyeSB7XG4gICAgICAvLyAxLiBXZSBtdXN0IHVzZSBGb3JtRGF0YSBiZWNhdXNlIHdlIGFyZSBzZW5kaW5nIGEgRmlsZSArIFRleHRcbiAgICAgIGNvbnN0IGZvcm1EYXRhID0gbmV3IEZvcm1EYXRhKCk7XG4gICAgICBmb3JtRGF0YS5hcHBlbmQoJ3RpdGxlJywgZm9ybS50aXRsZSk7XG4gICAgICBmb3JtRGF0YS5hcHBlbmQoJ2Rlc2NyaXB0aW9uJywgZm9ybS5kZXNjcmlwdGlvbik7XG4gICAgICBmb3JtRGF0YS5hcHBlbmQoJ3NldmVyaXR5JywgZm9ybS5zZXZlcml0eSk7XG4gICAgICBpZiAoZmlsZSkgZm9ybURhdGEuYXBwZW5kKCdsb2dzJywgZmlsZSk7XG5cbiAgICAgIC8vIDIuIENyZWF0ZSB0aGUgaW5jaWRlbnRcbiAgICAgIGNvbnN0IGNyZWF0ZVJlcyA9IGF3YWl0IGFwaS5wb3N0KCcvaW5jaWRlbnRzJywgZm9ybURhdGEsIHtcbiAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ211bHRpcGFydC9mb3JtLWRhdGEnIH1cbiAgICAgIH0pO1xuICAgICAgXG4gICAgICBjb25zdCBuZXdJbmNpZGVudElkID0gY3JlYXRlUmVzLmRhdGEuZGF0YS5faWQ7XG4gICAgICBzZXRJbmNpZGVudElkKG5ld0luY2lkZW50SWQpOyAvLyBUaGlzIHRyaWdnZXJzIHRoZSBzb2NrZXQgbGlzdGVuZXIgYWJvdmUhXG5cbiAgICAgIC8vIDMuIEtpY2sgb2ZmIHRoZSBBSSBQaXBlbGluZSBhc3luY2hyb25vdXNseVxuICAgICAgLy8gV2UgZG8gTk9UIGF3YWl0IHRoaXMgYmVjYXVzZSB3ZSB3YW50IHRvIHdhdGNoIGl0IHJ1biBsaXZlIGluIHRoZSBVSVxuICAgICAgYXBpLnBvc3QoYC9pbmNpZGVudHMvJHtuZXdJbmNpZGVudElkfS9hbmFseXNlYCkuY2F0Y2goZXJyID0+IHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIlBpcGVsaW5lIGVycm9yOlwiLCBlcnIpO1xuICAgICAgICBzZXRFcnJvcihcIkFJIFBpcGVsaW5lIGZhaWxlZCB0byBydW4uXCIpO1xuICAgICAgfSk7XG5cbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldEVycm9yKGVyci5yZXNwb25zZT8uZGF0YT8uZXJyb3IgfHwgJ0ZhaWxlZCB0byBjcmVhdGUgaW5jaWRlbnQnKTtcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctNHhsIG14LWF1dG8gc3BhY2UteS02XCI+XG4gICAgICA8ZGl2PlxuICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtd2hpdGVcIj5SZXBvcnQgTmV3IEluY2lkZW50PC9oMT5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgdGV4dC1zbVwiPlVwbG9hZCBsb2dzIGFuZCBsZXQgQUkgYW5hbHl6ZSB0aGUgcm9vdCBjYXVzZTwvcD5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7ZXJyb3IgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXJlZC01MDAvMTAgYm9yZGVyIGJvcmRlci1yZWQtNTAwIHRleHQtcmVkLTQwMCBwLTQgcm91bmRlZC1sZ1wiPlxuICAgICAgICAgIHtlcnJvcn1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogSWYgaW5jaWRlbnRJZCBleGlzdHMsIHRoZSBmb3JtIHdhcyBzdWJtaXR0ZWQuIFNob3cgdGhlIGxpdmUgQUkgc3RlcHBlciBpbnN0ZWFkLiAqL31cbiAgICAgIHtpbmNpZGVudElkID8gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNiBmYWRlLWluXCI+XG4gICAgICAgICAgPEFnZW50U3RlcHBlciBldmVudHM9e2FnZW50RXZlbnRzfSAvPlxuICAgICAgICAgIFxuICAgICAgICAgIHtwaXBlbGluZUNvbXBsZXRlICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JlZW4tNTAwLzEwIGJvcmRlciBib3JkZXItZ3JlZW4tNTAwLzMwIHAtNiByb3VuZGVkLXhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTQwMCBmb250LWJvbGQgdGV4dC1sZ1wiPkFuYWx5c2lzIENvbXBsZXRlITwvaDM+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi01MDAvODAgdGV4dC1zbSBtdC0xXCI+VGhlIEFJIGhhcyBnZW5lcmF0ZWQgYSBwb3N0LW1vcnRlbSBhbmQgcnVuYm9vayBzb2x1dGlvbi48L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoYC9pbmNpZGVudHMvJHtpbmNpZGVudElkfWApfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyZWVuLTYwMCBob3ZlcjpiZy1ncmVlbi03MDAgdGV4dC13aGl0ZSBweC02IHB5LTMgcm91bmRlZC1sZyBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBWaWV3IEZ1bGwgUmVwb3J0IOKGklxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKSA6IChcbiAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gY2xhc3NOYW1lPVwiYmctc2xhdGUtODAwIHJvdW5kZWQteGwgcC04IGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHNwYWNlLXktNlwiPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgdGV4dC1zbSBtYi0xIGJsb2NrIGZvbnQtbWVkaXVtXCI+SW5jaWRlbnQgVGl0bGU8L2xhYmVsPlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0udGl0bGV9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybSh7IC4uLmZvcm0sIHRpdGxlOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTYwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgcHgtNCBweS0zIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItaW5kaWdvLTUwMFwiXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiwgRGF0YWJhc2UgQ29ubmVjdGlvbiBUaW1lb3V0IGluIFByb2R1Y3Rpb25cIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgdGV4dC1zbSBtYi0xIGJsb2NrIGZvbnQtbWVkaXVtXCI+RGVzY3JpcHRpb248L2xhYmVsPlxuICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgIHJvd3M9XCI0XCJcbiAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0uZGVzY3JpcHRpb259XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybSh7IC4uLmZvcm0sIGRlc2NyaXB0aW9uOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTYwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgcHgtNCBweS0zIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItaW5kaWdvLTUwMFwiXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRGVzY3JpYmUgd2hhdCBoYXBwZW5lZCwgd2hlbiBpdCBzdGFydGVkLCBhbmQgdXNlciBpbXBhY3QuLi5cIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNlwiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIHRleHQtc20gbWItMSBibG9jayBmb250LW1lZGl1bVwiPlNldmVyaXR5PC9sYWJlbD5cbiAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtLnNldmVyaXR5fVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybSh7IC4uLmZvcm0sIHNldmVyaXR5OiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNjAwIHRleHQtd2hpdGUgcm91bmRlZC1sZyBweC00IHB5LTMgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJMb3dcIj5Mb3c8L29wdGlvbj5cbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiTWVkaXVtXCI+TWVkaXVtPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkhpZ2hcIj5IaWdoPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkNyaXRpY2FsXCI+Q3JpdGljYWw8L29wdGlvbj5cbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIHRleHQtc20gbWItMSBibG9jayBmb250LW1lZGl1bVwiPkF0dGFjaCBMb2cgRmlsZTwvbGFiZWw+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZpbGUoZS50YXJnZXQuZmlsZXNbMF0pfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS02MDAgdGV4dC1zbGF0ZS00MDAgcm91bmRlZC1sZyBweC00IHB5LTIuNSBmaWxlOm1yLTQgZmlsZTpweS0yIGZpbGU6cHgtNCBmaWxlOnJvdW5kZWQtZnVsbCBmaWxlOmJvcmRlci0wIGZpbGU6dGV4dC1zbSBmaWxlOmZvbnQtc2VtaWJvbGQgZmlsZTpiZy1pbmRpZ28tNTAwLzEwIGZpbGU6dGV4dC1pbmRpZ28tNDAwIGhvdmVyOmZpbGU6YmctaW5kaWdvLTUwMC8yMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtNCBib3JkZXItdCBib3JkZXItc2xhdGUtNzAwIGZsZXgganVzdGlmeS1lbmRcIj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKCcvaW5jaWRlbnRzJyl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTYgcHktMyB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlIGZvbnQtbWVkaXVtIG1yLTRcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBDYW5jZWxcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2xvYWRpbmd9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWluZGlnby02MDAgaG92ZXI6YmctaW5kaWdvLTcwMCBkaXNhYmxlZDpiZy1zbGF0ZS03MDAgZGlzYWJsZWQ6dGV4dC1zbGF0ZS01MDAgdGV4dC13aGl0ZSBweC04IHB5LTMgcm91bmRlZC1sZyBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWNvbG9ycyBzaGFkb3ctbGcgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7bG9hZGluZyA/IChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIHRleHQtbGdcIj7ij7M8L3NwYW4+IFVwbG9hZGluZy4uLlxuICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICDwn5qAIFN1Ym1pdCAmIFJ1biBBSVxuICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZm9ybT5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBOZXdJbmNpZGVudDtcbiJdLCJmaWxlIjoiQzovVXNlcnMvQW1pdGggVSBOYXlhay8uZ2VtaW5pL2FudGlncmF2aXR5L3NjcmF0Y2gvb3BzZ2VuaWVhaS9jbGllbnQvc3JjL3BhZ2VzL05ld0luY2lkZW50LmpzeCJ9