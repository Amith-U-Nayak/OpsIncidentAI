import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Dashboard.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1aa83cf1"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=1aa83cf1"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=3fc0a56c";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "/node_modules/.vite/deps/recharts.js?v=b7e021e8";
import api from "/src/api/axios.js";
const SEVERITY_COLORS = {
  Critical: "#ef4444",
  High: "#f97316",
  Medium: "#eab308",
  Low: "#3b82f6"
};
const Dashboard = () => {
  _s();
  const [summary, setSummary] = useState(null);
  const [severityData, setSeverityData] = useState([]);
  const [weeklyData, setWeeklyData] = useState([]);
  const [mttr, setMttr] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        const [summaryRes, severityRes, weeklyRes, mttrRes] = await Promise.all(
          [
            api.get("/analytics/summary"),
            api.get("/analytics/severity"),
            api.get("/analytics/weekly"),
            api.get("/analytics/mttr")
          ]
        );
        setSummary(summaryRes.data.data);
        setSeverityData(severityRes.data.data);
        setWeeklyData(weeklyRes.data.data);
        setMttr(mttrRes.data.data);
      } catch (err) {
        setError("Failed to load dashboard data. Please refresh.");
      } finally {
        setLoading(false);
      }
    };
    fetchAnalytics();
  }, []);
  if (loading) {
    return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center h-full", children: /* @__PURE__ */ jsxDEV("div", { className: "text-indigo-400 animate-pulse text-lg", children: "Loading Analytics..." }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
      lineNumber: 72,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
      lineNumber: 71,
      columnNumber: 7
    }, this);
  }
  if (error) {
    return /* @__PURE__ */ jsxDEV("div", { className: "bg-red-500/10 border border-red-500 text-red-400 p-4 rounded-lg", children: error }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
      lineNumber: 79,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-6 max-w-6xl mx-auto", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-white", children: "System Overview" }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
          lineNumber: 89,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-slate-400 text-sm", children: "Real-time incident analytics" }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
          lineNumber: 90,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
        lineNumber: 88,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Link,
        {
          to: "/incidents/new",
          className: "bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg font-medium transition-colors flex items-center gap-2 shadow-lg shadow-indigo-500/20",
          children: [
            /* @__PURE__ */ jsxDEV("span", { children: "➕" }, void 0, false, {
              fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
              lineNumber: 97,
              columnNumber: 11
            }, this),
            " Report Incident"
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
          lineNumber: 93,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
      lineNumber: 87,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "bg-slate-800 p-5 rounded-xl border border-slate-700", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-slate-400 text-sm font-medium", children: "Total Incidents" }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
          lineNumber: 104,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-white mt-2", children: summary?.totalIncidents }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
          lineNumber: 105,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
        lineNumber: 103,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-slate-800 p-5 rounded-xl border border-slate-700", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-slate-400 text-sm font-medium", children: "Open / Investigating" }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
          lineNumber: 108,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-yellow-400 mt-2", children: [
          summary?.openIncidents,
          " / ",
          summary?.investigatingIncidents
        ] }, void 0, true, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
          lineNumber: 109,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
        lineNumber: 107,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-slate-800 p-5 rounded-xl border border-slate-700", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-slate-400 text-sm font-medium", children: "Critical Incidents" }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
          lineNumber: 114,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-red-500 mt-2", children: summary?.criticalIncidents }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
          lineNumber: 115,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
        lineNumber: 113,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-slate-800 p-5 rounded-xl border border-slate-700", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-slate-400 text-sm font-medium", children: "Mean Time To Resolve (MTTR)" }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
          lineNumber: 118,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-green-400 mt-2", children: mttr?.mttrMinutes > 0 ? `${mttr.mttrMinutes}m` : "N/A" }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
          lineNumber: 119,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-slate-500 text-xs mt-1", children: "Industry target: < 30m" }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
          lineNumber: 122,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
        lineNumber: 117,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
      lineNumber: 102,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 lg:grid-cols-3 gap-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "bg-slate-800 p-5 rounded-xl border border-slate-700 lg:col-span-2 h-96 flex flex-col", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-white font-semibold mb-4", children: "Incident Volume (Last 8 Weeks)" }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
          lineNumber: 129,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-h-0", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: "100%", children: /* @__PURE__ */ jsxDEV(LineChart, { data: weeklyData, children: [
          /* @__PURE__ */ jsxDEV(CartesianGrid, { strokeDasharray: "3 3", stroke: "#334155", vertical: false }, void 0, false, {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
            lineNumber: 133,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            XAxis,
            {
              dataKey: "week",
              stroke: "#94a3b8",
              tickFormatter: (val) => `W${val}`,
              tick: { fontSize: 12 }
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
              lineNumber: 134,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(YAxis, { stroke: "#94a3b8", allowDecimals: false, tick: { fontSize: 12 } }, void 0, false, {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
            lineNumber: 140,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            Tooltip,
            {
              contentStyle: { backgroundColor: "#1e293b", border: "1px solid #334155", borderRadius: "8px", color: "#f8fafc" },
              itemStyle: { color: "#818cf8" },
              labelFormatter: (val) => `Week ${val}`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
              lineNumber: 141,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Line,
            {
              type: "monotone",
              dataKey: "count",
              stroke: "#818cf8",
              strokeWidth: 3,
              dot: { r: 4, fill: "#818cf8", strokeWidth: 2, stroke: "#1e293b" },
              activeDot: { r: 6 }
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
              lineNumber: 146,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
          lineNumber: 132,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
          lineNumber: 131,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
          lineNumber: 130,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
        lineNumber: 128,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-slate-800 p-5 rounded-xl border border-slate-700 h-96 flex flex-col", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-white font-semibold mb-4", children: "Incidents by Severity" }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
          lineNumber: 161,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-h-0 flex items-center justify-center", children: severityData.length > 0 ? /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: "100%", children: /* @__PURE__ */ jsxDEV(PieChart, { children: [
          /* @__PURE__ */ jsxDEV(
            Pie,
            {
              data: severityData,
              cx: "50%",
              cy: "50%",
              innerRadius: 60,
              outerRadius: 80,
              paddingAngle: 5,
              dataKey: "count",
              nameKey: "severity",
              children: severityData.map(
                (entry, index) => /* @__PURE__ */ jsxDEV(Cell, { fill: SEVERITY_COLORS[entry.severity] || "#94a3b8" }, `cell-${index}`, false, {
                  fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
                  lineNumber: 177,
                  columnNumber: 19
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
              lineNumber: 166,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Tooltip,
            {
              contentStyle: { backgroundColor: "#1e293b", border: "none", borderRadius: "8px", color: "#f8fafc" },
              itemStyle: { color: "#f8fafc" }
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
              lineNumber: 180,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
          lineNumber: 165,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
          lineNumber: 164,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV("p", { className: "text-slate-500 text-sm", children: "No data available" }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
          lineNumber: 187,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
          lineNumber: 162,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-3 justify-center mt-4", children: severityData.map(
          (entry) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 text-xs text-slate-300", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-3 h-3 rounded-full", style: { backgroundColor: SEVERITY_COLORS[entry.severity] } }, void 0, false, {
              fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
              lineNumber: 194,
              columnNumber: 17
            }, this),
            entry.severity,
            " (",
            entry.count,
            ")"
          ] }, entry.severity, true, {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
            lineNumber: 193,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
          lineNumber: 191,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
        lineNumber: 160,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
      lineNumber: 126,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx",
    lineNumber: 86,
    columnNumber: 5
  }, this);
};
_s(Dashboard, "qT9QuD8Zt6+xF6n8sWcarr+euQA=");
_c = Dashboard;
export default Dashboard;
var _c;
$RefreshReg$(_c, "Dashboard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Dashboard.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0RROzs7Ozs7Ozs7Ozs7Ozs7OztBQXBEUixTQUFTQSxVQUFVQyxpQkFBaUI7QUFDcEMsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxXQUFXQyxNQUFNQyxPQUFPQyxPQUFPQyxlQUFlQyxTQUFTQyxxQkFBcUJDLFVBQVVDLEtBQUtDLFlBQVk7QUFDaEgsT0FBT0MsU0FBUztBQUloQixNQUFNQyxrQkFBa0I7QUFBQSxFQUN0QkMsVUFBVTtBQUFBLEVBQ1ZDLE1BQU07QUFBQSxFQUNOQyxRQUFRO0FBQUEsRUFDUkMsS0FBSztBQUNQO0FBRUEsTUFBTUMsWUFBWUEsTUFBTTtBQUFBQyxLQUFBO0FBQ3RCLFFBQU0sQ0FBQ0MsU0FBU0MsVUFBVSxJQUFJdEIsU0FBUyxJQUFJO0FBQzNDLFFBQU0sQ0FBQ3VCLGNBQWNDLGVBQWUsSUFBSXhCLFNBQVMsRUFBRTtBQUNuRCxRQUFNLENBQUN5QixZQUFZQyxhQUFhLElBQUkxQixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDMkIsTUFBTUMsT0FBTyxJQUFJNUIsU0FBUyxJQUFJO0FBQ3JDLFFBQU0sQ0FBQzZCLFNBQVNDLFVBQVUsSUFBSTlCLFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUMrQixPQUFPQyxRQUFRLElBQUloQyxTQUFTLEVBQUU7QUFFckNDLFlBQVUsTUFBTTtBQUVkLFVBQU1nQyxpQkFBaUIsWUFBWTtBQUNqQyxVQUFJO0FBRUYsY0FBTSxDQUFDQyxZQUFZQyxhQUFhQyxXQUFXQyxPQUFPLElBQUksTUFBTUMsUUFBUUM7QUFBQUEsVUFBSTtBQUFBLFlBQ3RFMUIsSUFBSTJCLElBQUksb0JBQW9CO0FBQUEsWUFDNUIzQixJQUFJMkIsSUFBSSxxQkFBcUI7QUFBQSxZQUM3QjNCLElBQUkyQixJQUFJLG1CQUFtQjtBQUFBLFlBQzNCM0IsSUFBSTJCLElBQUksaUJBQWlCO0FBQUEsVUFBQztBQUFBLFFBQzNCO0FBRURsQixtQkFBV1ksV0FBV08sS0FBS0EsSUFBSTtBQUMvQmpCLHdCQUFnQlcsWUFBWU0sS0FBS0EsSUFBSTtBQUNyQ2Ysc0JBQWNVLFVBQVVLLEtBQUtBLElBQUk7QUFDakNiLGdCQUFRUyxRQUFRSSxLQUFLQSxJQUFJO0FBQUEsTUFDM0IsU0FBU0MsS0FBSztBQUVaVixpQkFBUyxnREFBZ0Q7QUFBQSxNQUMzRCxVQUFDO0FBQ0NGLG1CQUFXLEtBQUs7QUFBQSxNQUNsQjtBQUFBLElBQ0Y7QUFFQUcsbUJBQWU7QUFBQSxFQUNqQixHQUFHLEVBQUU7QUFFTCxNQUFJSixTQUFTO0FBQ1gsV0FDRSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2IsaUNBQUMsU0FBSSxXQUFVLHlDQUF3QyxvQ0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyRSxLQUQ3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBRUEsTUFBSUUsT0FBTztBQUNULFdBQ0UsdUJBQUMsU0FBSSxXQUFVLG1FQUNaQSxtQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSw2QkFBQyxTQUNDO0FBQUEsK0JBQUMsUUFBRyxXQUFVLGlDQUFnQywrQkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2RDtBQUFBLFFBQzdELHVCQUFDLE9BQUUsV0FBVSwwQkFBeUIsNENBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0U7QUFBQSxXQUZwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUVBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxJQUFHO0FBQUEsVUFDSCxXQUFVO0FBQUEsVUFFVjtBQUFBLG1DQUFDLFVBQUssaUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBTztBQUFBLFlBQU87QUFBQTtBQUFBO0FBQUEsUUFKaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS0E7QUFBQSxTQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLHdEQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHVEQUNiO0FBQUEsK0JBQUMsT0FBRSxXQUFVLHNDQUFxQywrQkFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRTtBQUFBLFFBQ2pFLHVCQUFDLE9BQUUsV0FBVSxzQ0FBc0NWLG1CQUFTc0Isa0JBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkU7QUFBQSxXQUY3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSx1REFDYjtBQUFBLCtCQUFDLE9BQUUsV0FBVSxzQ0FBcUMsb0NBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0U7QUFBQSxRQUN0RSx1QkFBQyxPQUFFLFdBQVUsMkNBQ1Z0QjtBQUFBQSxtQkFBU3VCO0FBQUFBLFVBQWM7QUFBQSxVQUFJdkIsU0FBU3dCO0FBQUFBLGFBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsdURBQ2I7QUFBQSwrQkFBQyxPQUFFLFdBQVUsc0NBQXFDLGtDQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9FO0FBQUEsUUFDcEUsdUJBQUMsT0FBRSxXQUFVLHdDQUF3Q3hCLG1CQUFTeUIscUJBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0Y7QUFBQSxXQUZsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSx1REFDYjtBQUFBLCtCQUFDLE9BQUUsV0FBVSxzQ0FBcUMsMkNBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkU7QUFBQSxRQUM3RSx1QkFBQyxPQUFFLFdBQVUsMENBQ1ZuQixnQkFBTW9CLGNBQWMsSUFBSSxHQUFHcEIsS0FBS29CLFdBQVcsTUFBTSxTQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSwrQkFBOEIsc0NBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0U7QUFBQSxXQUx0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUE7QUFBQSxTQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0JBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUseUNBRWI7QUFBQSw2QkFBQyxTQUFJLFdBQVUsd0ZBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsaUNBQWdDLDhDQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRFO0FBQUEsUUFDNUUsdUJBQUMsU0FBSSxXQUFVLGtCQUNiLGlDQUFDLHVCQUFvQixPQUFNLFFBQU8sUUFBTyxRQUN2QyxpQ0FBQyxhQUFVLE1BQU10QixZQUNmO0FBQUEsaUNBQUMsaUJBQWMsaUJBQWdCLE9BQU0sUUFBTyxXQUFVLFVBQVUsU0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0U7QUFBQSxVQUN0RTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUTtBQUFBLGNBQ1IsUUFBTztBQUFBLGNBQ1AsZUFBZSxDQUFDdUIsUUFBUSxJQUFJQSxHQUFHO0FBQUEsY0FDL0IsTUFBTSxFQUFFQyxVQUFVLEdBQUc7QUFBQTtBQUFBLFlBSnZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUl5QjtBQUFBLFVBRXpCLHVCQUFDLFNBQU0sUUFBTyxXQUFVLGVBQWUsT0FBTyxNQUFNLEVBQUVBLFVBQVUsR0FBRyxLQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRTtBQUFBLFVBQ3JFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxjQUFjLEVBQUVDLGlCQUFpQixXQUFXQyxRQUFRLHFCQUFxQkMsY0FBYyxPQUFPQyxPQUFPLFVBQVU7QUFBQSxjQUMvRyxXQUFXLEVBQUVBLE9BQU8sVUFBVTtBQUFBLGNBQzlCLGdCQUFnQixDQUFDTCxRQUFRLFFBQVFBLEdBQUc7QUFBQTtBQUFBLFlBSHRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUd5QztBQUFBLFVBRXpDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFRO0FBQUEsY0FDUixRQUFPO0FBQUEsY0FDUCxhQUFhO0FBQUEsY0FDYixLQUFLLEVBQUVNLEdBQUcsR0FBR0MsTUFBTSxXQUFXQyxhQUFhLEdBQUdDLFFBQVEsVUFBVTtBQUFBLGNBQ2hFLFdBQVcsRUFBRUgsR0FBRyxFQUFFO0FBQUE7QUFBQSxZQU5wQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNc0I7QUFBQSxhQXBCeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXNCQSxLQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBLEtBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwQkE7QUFBQSxXQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNkJBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsMEVBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsaUNBQWdDLHFDQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1FO0FBQUEsUUFDbkUsdUJBQUMsU0FBSSxXQUFVLG1EQUNaL0IsdUJBQWFtQyxTQUFTLElBQ3JCLHVCQUFDLHVCQUFvQixPQUFNLFFBQU8sUUFBTyxRQUN2QyxpQ0FBQyxZQUNDO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQU1uQztBQUFBQSxjQUNOLElBQUc7QUFBQSxjQUNILElBQUc7QUFBQSxjQUNILGFBQWE7QUFBQSxjQUNiLGFBQWE7QUFBQSxjQUNiLGNBQWM7QUFBQSxjQUNkLFNBQVE7QUFBQSxjQUNSLFNBQVE7QUFBQSxjQUVQQSx1QkFBYW9DO0FBQUFBLGdCQUFJLENBQUNDLE9BQU9DLFVBQ3hCLHVCQUFDLFFBQTJCLE1BQU0vQyxnQkFBZ0I4QyxNQUFNRSxRQUFRLEtBQUssYUFBMUQsUUFBUUQsS0FBSyxJQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUErRTtBQUFBLGNBQ2hGO0FBQUE7QUFBQSxZQVpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWFBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsY0FBYyxFQUFFWCxpQkFBaUIsV0FBV0MsUUFBUSxRQUFRQyxjQUFjLE9BQU9DLE9BQU8sVUFBVTtBQUFBLGNBQ2xHLFdBQVcsRUFBRUEsT0FBTyxVQUFVO0FBQUE7QUFBQSxZQUZoQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFFa0M7QUFBQSxhQWpCcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1CQSxLQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcUJBLElBRUEsdUJBQUMsT0FBRSxXQUFVLDBCQUF5QixpQ0FBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RCxLQXpCM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTJCQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDRDQUNaOUIsdUJBQWFvQztBQUFBQSxVQUFJLENBQUNDLFVBQ2pCLHVCQUFDLFNBQXlCLFdBQVUsb0RBQ2xDO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHdCQUF1QixPQUFPLEVBQUVWLGlCQUFpQnBDLGdCQUFnQjhDLE1BQU1FLFFBQVEsRUFBRSxLQUFoRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRztBQUFBLFlBQ2xHRixNQUFNRTtBQUFBQSxZQUFTO0FBQUEsWUFBR0YsTUFBTUc7QUFBQUEsWUFBTTtBQUFBLGVBRnZCSCxNQUFNRSxVQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsUUFDRCxLQU5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFdBdENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1Q0E7QUFBQSxTQXpFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMEVBO0FBQUEsT0FsSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1IQTtBQUVKO0FBQUUxQyxHQXpLSUQsV0FBUztBQUFBLEtBQVRBO0FBMktOLGVBQWVBO0FBQVUsSUFBQTZDO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwiTGluayIsIkxpbmVDaGFydCIsIkxpbmUiLCJYQXhpcyIsIllBeGlzIiwiQ2FydGVzaWFuR3JpZCIsIlRvb2x0aXAiLCJSZXNwb25zaXZlQ29udGFpbmVyIiwiUGllQ2hhcnQiLCJQaWUiLCJDZWxsIiwiYXBpIiwiU0VWRVJJVFlfQ09MT1JTIiwiQ3JpdGljYWwiLCJIaWdoIiwiTWVkaXVtIiwiTG93IiwiRGFzaGJvYXJkIiwiX3MiLCJzdW1tYXJ5Iiwic2V0U3VtbWFyeSIsInNldmVyaXR5RGF0YSIsInNldFNldmVyaXR5RGF0YSIsIndlZWtseURhdGEiLCJzZXRXZWVrbHlEYXRhIiwibXR0ciIsInNldE10dHIiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImVycm9yIiwic2V0RXJyb3IiLCJmZXRjaEFuYWx5dGljcyIsInN1bW1hcnlSZXMiLCJzZXZlcml0eVJlcyIsIndlZWtseVJlcyIsIm10dHJSZXMiLCJQcm9taXNlIiwiYWxsIiwiZ2V0IiwiZGF0YSIsImVyciIsInRvdGFsSW5jaWRlbnRzIiwib3BlbkluY2lkZW50cyIsImludmVzdGlnYXRpbmdJbmNpZGVudHMiLCJjcml0aWNhbEluY2lkZW50cyIsIm10dHJNaW51dGVzIiwidmFsIiwiZm9udFNpemUiLCJiYWNrZ3JvdW5kQ29sb3IiLCJib3JkZXIiLCJib3JkZXJSYWRpdXMiLCJjb2xvciIsInIiLCJmaWxsIiwic3Ryb2tlV2lkdGgiLCJzdHJva2UiLCJsZW5ndGgiLCJtYXAiLCJlbnRyeSIsImluZGV4Iiwic2V2ZXJpdHkiLCJjb3VudCIsIl9jIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkRhc2hib2FyZC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IExpbmVDaGFydCwgTGluZSwgWEF4aXMsIFlBeGlzLCBDYXJ0ZXNpYW5HcmlkLCBUb29sdGlwLCBSZXNwb25zaXZlQ29udGFpbmVyLCBQaWVDaGFydCwgUGllLCBDZWxsIH0gZnJvbSAncmVjaGFydHMnO1xuaW1wb3J0IGFwaSBmcm9tICcuLi9hcGkvYXhpb3MnO1xuXG4vLyBIQ0kgUHJpbmNpcGxlOiBDb2xvciBjb2RpbmcgYnVpbGRzIGEgbWVudGFsIG1vZGVsLlxuLy8gQ3JpdGljYWwgPSBSZWQgKERhbmdlciksIEhpZ2ggPSBPcmFuZ2UgKFdhcm5pbmcpLCBNZWRpdW0gPSBZZWxsb3csIExvdyA9IEJsdWUgKEluZm8pXG5jb25zdCBTRVZFUklUWV9DT0xPUlMgPSB7XG4gIENyaXRpY2FsOiAnI2VmNDQ0NCcsIFxuICBIaWdoOiAnI2Y5NzMxNicsICAgICBcbiAgTWVkaXVtOiAnI2VhYjMwOCcsICAgXG4gIExvdzogJyMzYjgyZjYnICAgICAgIFxufTtcblxuY29uc3QgRGFzaGJvYXJkID0gKCkgPT4ge1xuICBjb25zdCBbc3VtbWFyeSwgc2V0U3VtbWFyeV0gPSB1c2VTdGF0ZShudWxsKTtcbiAgY29uc3QgW3NldmVyaXR5RGF0YSwgc2V0U2V2ZXJpdHlEYXRhXSA9IHVzZVN0YXRlKFtdKTtcbiAgY29uc3QgW3dlZWtseURhdGEsIHNldFdlZWtseURhdGFdID0gdXNlU3RhdGUoW10pO1xuICBjb25zdCBbbXR0ciwgc2V0TXR0cl0gPSB1c2VTdGF0ZShudWxsKTtcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoJycpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgLy8gSENJIFByaW5jaXBsZTogRmVlZGJhY2suIFNob3cgbG9hZGluZyBzdGF0ZSB3aGlsZSBmZXRjaGluZy5cbiAgICBjb25zdCBmZXRjaEFuYWx5dGljcyA9IGFzeW5jICgpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIC8vIEZldGNoIGFsbCBkYXNoYm9hcmQgZGF0YSBjb25jdXJyZW50bHlcbiAgICAgICAgY29uc3QgW3N1bW1hcnlSZXMsIHNldmVyaXR5UmVzLCB3ZWVrbHlSZXMsIG10dHJSZXNdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xuICAgICAgICAgIGFwaS5nZXQoJy9hbmFseXRpY3Mvc3VtbWFyeScpLFxuICAgICAgICAgIGFwaS5nZXQoJy9hbmFseXRpY3Mvc2V2ZXJpdHknKSxcbiAgICAgICAgICBhcGkuZ2V0KCcvYW5hbHl0aWNzL3dlZWtseScpLFxuICAgICAgICAgIGFwaS5nZXQoJy9hbmFseXRpY3MvbXR0cicpXG4gICAgICAgIF0pO1xuXG4gICAgICAgIHNldFN1bW1hcnkoc3VtbWFyeVJlcy5kYXRhLmRhdGEpO1xuICAgICAgICBzZXRTZXZlcml0eURhdGEoc2V2ZXJpdHlSZXMuZGF0YS5kYXRhKTtcbiAgICAgICAgc2V0V2Vla2x5RGF0YSh3ZWVrbHlSZXMuZGF0YS5kYXRhKTtcbiAgICAgICAgc2V0TXR0cihtdHRyUmVzLmRhdGEuZGF0YSk7XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgLy8gSENJIFByaW5jaXBsZTogRXJyb3IgUmVjb3ZlcnkuIFRlbGwgdGhlIHVzZXIgd2hhdCB3ZW50IHdyb25nLlxuICAgICAgICBzZXRFcnJvcignRmFpbGVkIHRvIGxvYWQgZGFzaGJvYXJkIGRhdGEuIFBsZWFzZSByZWZyZXNoLicpO1xuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICB9XG4gICAgfTtcblxuICAgIGZldGNoQW5hbHl0aWNzKCk7XG4gIH0sIFtdKTtcblxuICBpZiAobG9hZGluZykge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGgtZnVsbFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtaW5kaWdvLTQwMCBhbmltYXRlLXB1bHNlIHRleHQtbGdcIj5Mb2FkaW5nIEFuYWx5dGljcy4uLjwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxuXG4gIGlmIChlcnJvcikge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXJlZC01MDAvMTAgYm9yZGVyIGJvcmRlci1yZWQtNTAwIHRleHQtcmVkLTQwMCBwLTQgcm91bmRlZC1sZ1wiPlxuICAgICAgICB7ZXJyb3J9XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNiBtYXgtdy02eGwgbXgtYXV0b1wiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtd2hpdGVcIj5TeXN0ZW0gT3ZlcnZpZXc8L2gxPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIHRleHQtc21cIj5SZWFsLXRpbWUgaW5jaWRlbnQgYW5hbHl0aWNzPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgey8qIEhDSSBQcmluY2lwbGU6IFByaW1hcnkgQWN0aW9uIGlzIGRpc3RpbmN0IGFuZCBlYXNpbHkgYWNjZXNzaWJsZSAqL31cbiAgICAgICAgPExpbmsgXG4gICAgICAgICAgdG89XCIvaW5jaWRlbnRzL25ld1wiIFxuICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWluZGlnby02MDAgaG92ZXI6YmctaW5kaWdvLTcwMCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkLWxnIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tY29sb3JzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHNoYWRvdy1sZyBzaGFkb3ctaW5kaWdvLTUwMC8yMFwiXG4gICAgICAgID5cbiAgICAgICAgICA8c3Bhbj7inpU8L3NwYW4+IFJlcG9ydCBJbmNpZGVudFxuICAgICAgICA8L0xpbms+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIEhDSSBQcmluY2lwbGU6IEdsYW5jZWFiaWxpdHkuIFRvcCBLUEkgY2FyZHMgY2h1bmsgdGhlIG1vc3Qgdml0YWwgaW5mby4gKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTRcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS04MDAgcC01IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDBcIj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCB0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+VG90YWwgSW5jaWRlbnRzPC9wPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIG10LTJcIj57c3VtbWFyeT8udG90YWxJbmNpZGVudHN9PC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS04MDAgcC01IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDBcIj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCB0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+T3BlbiAvIEludmVzdGlnYXRpbmc8L3A+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQteWVsbG93LTQwMCBtdC0yXCI+XG4gICAgICAgICAgICB7c3VtbWFyeT8ub3BlbkluY2lkZW50c30gLyB7c3VtbWFyeT8uaW52ZXN0aWdhdGluZ0luY2lkZW50c31cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTgwMCBwLTUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMFwiPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIHRleHQtc20gZm9udC1tZWRpdW1cIj5Dcml0aWNhbCBJbmNpZGVudHM8L3A+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtcmVkLTUwMCBtdC0yXCI+e3N1bW1hcnk/LmNyaXRpY2FsSW5jaWRlbnRzfTwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtODAwIHAtNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtNzAwXCI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgdGV4dC1zbSBmb250LW1lZGl1bVwiPk1lYW4gVGltZSBUbyBSZXNvbHZlIChNVFRSKTwvcD5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC1ncmVlbi00MDAgbXQtMlwiPlxuICAgICAgICAgICAge210dHI/Lm10dHJNaW51dGVzID4gMCA/IGAke210dHIubXR0ck1pbnV0ZXN9bWAgOiAnTi9BJ31cbiAgICAgICAgICA8L3A+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgdGV4dC14cyBtdC0xXCI+SW5kdXN0cnkgdGFyZ2V0OiAmbHQ7IDMwbTwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0zIGdhcC02XCI+XG4gICAgICAgIHsvKiBXZWVrbHkgVHJlbmQgTGluZSBDaGFydCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS04MDAgcC01IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgbGc6Y29sLXNwYW4tMiBoLTk2IGZsZXggZmxleC1jb2xcIj5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSBmb250LXNlbWlib2xkIG1iLTRcIj5JbmNpZGVudCBWb2x1bWUgKExhc3QgOCBXZWVrcyk8L2gyPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi1oLTBcIj5cbiAgICAgICAgICAgIDxSZXNwb25zaXZlQ29udGFpbmVyIHdpZHRoPVwiMTAwJVwiIGhlaWdodD1cIjEwMCVcIj5cbiAgICAgICAgICAgICAgPExpbmVDaGFydCBkYXRhPXt3ZWVrbHlEYXRhfT5cbiAgICAgICAgICAgICAgICA8Q2FydGVzaWFuR3JpZCBzdHJva2VEYXNoYXJyYXk9XCIzIDNcIiBzdHJva2U9XCIjMzM0MTU1XCIgdmVydGljYWw9e2ZhbHNlfSAvPlxuICAgICAgICAgICAgICAgIDxYQXhpcyBcbiAgICAgICAgICAgICAgICAgIGRhdGFLZXk9XCJ3ZWVrXCIgXG4gICAgICAgICAgICAgICAgICBzdHJva2U9XCIjOTRhM2I4XCIgXG4gICAgICAgICAgICAgICAgICB0aWNrRm9ybWF0dGVyPXsodmFsKSA9PiBgVyR7dmFsfWB9IFxuICAgICAgICAgICAgICAgICAgdGljaz17eyBmb250U2l6ZTogMTIgfX0gXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8WUF4aXMgc3Ryb2tlPVwiIzk0YTNiOFwiIGFsbG93RGVjaW1hbHM9e2ZhbHNlfSB0aWNrPXt7IGZvbnRTaXplOiAxMiB9fSAvPlxuICAgICAgICAgICAgICAgIDxUb29sdGlwIFxuICAgICAgICAgICAgICAgICAgY29udGVudFN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogJyMxZTI5M2InLCBib3JkZXI6ICcxcHggc29saWQgIzMzNDE1NScsIGJvcmRlclJhZGl1czogJzhweCcsIGNvbG9yOiAnI2Y4ZmFmYycgfX1cbiAgICAgICAgICAgICAgICAgIGl0ZW1TdHlsZT17eyBjb2xvcjogJyM4MThjZjgnIH19XG4gICAgICAgICAgICAgICAgICBsYWJlbEZvcm1hdHRlcj17KHZhbCkgPT4gYFdlZWsgJHt2YWx9YH1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDxMaW5lIFxuICAgICAgICAgICAgICAgICAgdHlwZT1cIm1vbm90b25lXCIgXG4gICAgICAgICAgICAgICAgICBkYXRhS2V5PVwiY291bnRcIiBcbiAgICAgICAgICAgICAgICAgIHN0cm9rZT1cIiM4MThjZjhcIiBcbiAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPXszfSBcbiAgICAgICAgICAgICAgICAgIGRvdD17eyByOiA0LCBmaWxsOiAnIzgxOGNmOCcsIHN0cm9rZVdpZHRoOiAyLCBzdHJva2U6ICcjMWUyOTNiJyB9fSBcbiAgICAgICAgICAgICAgICAgIGFjdGl2ZURvdD17eyByOiA2IH19IFxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvTGluZUNoYXJ0PlxuICAgICAgICAgICAgPC9SZXNwb25zaXZlQ29udGFpbmVyPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogU2V2ZXJpdHkgUGllIENoYXJ0ICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTgwMCBwLTUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCBoLTk2IGZsZXggZmxleC1jb2xcIj5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSBmb250LXNlbWlib2xkIG1iLTRcIj5JbmNpZGVudHMgYnkgU2V2ZXJpdHk8L2gyPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi1oLTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgIHtzZXZlcml0eURhdGEubGVuZ3RoID4gMCA/IChcbiAgICAgICAgICAgICAgPFJlc3BvbnNpdmVDb250YWluZXIgd2lkdGg9XCIxMDAlXCIgaGVpZ2h0PVwiMTAwJVwiPlxuICAgICAgICAgICAgICAgIDxQaWVDaGFydD5cbiAgICAgICAgICAgICAgICAgIDxQaWVcbiAgICAgICAgICAgICAgICAgICAgZGF0YT17c2V2ZXJpdHlEYXRhfVxuICAgICAgICAgICAgICAgICAgICBjeD1cIjUwJVwiXG4gICAgICAgICAgICAgICAgICAgIGN5PVwiNTAlXCJcbiAgICAgICAgICAgICAgICAgICAgaW5uZXJSYWRpdXM9ezYwfVxuICAgICAgICAgICAgICAgICAgICBvdXRlclJhZGl1cz17ODB9XG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmdBbmdsZT17NX1cbiAgICAgICAgICAgICAgICAgICAgZGF0YUtleT1cImNvdW50XCJcbiAgICAgICAgICAgICAgICAgICAgbmFtZUtleT1cInNldmVyaXR5XCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge3NldmVyaXR5RGF0YS5tYXAoKGVudHJ5LCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxDZWxsIGtleT17YGNlbGwtJHtpbmRleH1gfSBmaWxsPXtTRVZFUklUWV9DT0xPUlNbZW50cnkuc2V2ZXJpdHldIHx8ICcjOTRhM2I4J30gLz5cbiAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICA8L1BpZT5cbiAgICAgICAgICAgICAgICAgIDxUb29sdGlwIFxuICAgICAgICAgICAgICAgICAgICBjb250ZW50U3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiAnIzFlMjkzYicsIGJvcmRlcjogJ25vbmUnLCBib3JkZXJSYWRpdXM6ICc4cHgnLCBjb2xvcjogJyNmOGZhZmMnIH19XG4gICAgICAgICAgICAgICAgICAgIGl0ZW1TdHlsZT17eyBjb2xvcjogJyNmOGZhZmMnIH19XG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvUGllQ2hhcnQ+XG4gICAgICAgICAgICAgIDwvUmVzcG9uc2l2ZUNvbnRhaW5lcj5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIHRleHQtc21cIj5ObyBkYXRhIGF2YWlsYWJsZTwvcD5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgey8qIEN1c3RvbSBMZWdlbmQgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMyBqdXN0aWZ5LWNlbnRlciBtdC00XCI+XG4gICAgICAgICAgICB7c2V2ZXJpdHlEYXRhLm1hcCgoZW50cnkpID0+IChcbiAgICAgICAgICAgICAgPGRpdiBrZXk9e2VudHJ5LnNldmVyaXR5fSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQteHMgdGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMyBoLTMgcm91bmRlZC1mdWxsXCIgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBTRVZFUklUWV9DT0xPUlNbZW50cnkuc2V2ZXJpdHldIH19PjwvZGl2PlxuICAgICAgICAgICAgICAgIHtlbnRyeS5zZXZlcml0eX0gKHtlbnRyeS5jb3VudH0pXG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBEYXNoYm9hcmQ7XG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FtaXRoIFUgTmF5YWsvLmdlbWluaS9hbnRpZ3Jhdml0eS9zY3JhdGNoL29wc2dlbmllYWkvY2xpZW50L3NyYy9wYWdlcy9EYXNoYm9hcmQuanN4In0=