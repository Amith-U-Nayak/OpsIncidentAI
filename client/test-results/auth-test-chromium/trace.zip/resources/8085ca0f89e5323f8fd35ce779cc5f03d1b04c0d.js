import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Register.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1aa83cf1"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=1aa83cf1"; const useState = __vite__cjsImport3_react["useState"];
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=3fc0a56c";
import api from "/src/api/axios.js";
const Register = () => {
  _s();
  const [form, setForm] = useState({ name: "", email: "", password: "", organization: "", role: "engineer" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await api.post("/auth/register", form);
      navigate("/login");
    } catch (err) {
      setError(err.response?.data?.message || "Registration failed");
    } finally {
      setLoading(false);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-slate-900 flex items-center justify-center p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full max-w-md", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "text-center mb-8", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold text-white", children: "⚡ OpsIncidentAI" }, void 0, false, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
        lineNumber: 51,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-slate-400 mt-2", children: "AI-Powered Incident Management" }, void 0, false, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
        lineNumber: 52,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
      lineNumber: 50,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-slate-800 rounded-2xl p-8 border border-slate-700", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-semibold text-white mb-6", children: "Create Account" }, void 0, false, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
        lineNumber: 56,
        columnNumber: 11
      }, this),
      error && /* @__PURE__ */ jsxDEV("div", { className: "bg-red-500/10 border border-red-500/30 text-red-400 rounded-lg p-3 mb-4 text-sm", children: error }, void 0, false, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
        lineNumber: 59,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-slate-400 text-sm mb-1 block", children: "Full Name" }, void 0, false, {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
            lineNumber: 66,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              value: form.name,
              onChange: (e) => setForm({ ...form, name: e.target.value }),
              className: "w-full bg-slate-900 border border-slate-600 text-white rounded-lg px-4 py-3 focus:outline-none focus:border-indigo-500",
              placeholder: "Enter your full name",
              required: true
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
              lineNumber: 67,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
          lineNumber: 65,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-slate-400 text-sm mb-1 block", children: "Email" }, void 0, false, {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
            lineNumber: 77,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "email",
              value: form.email,
              onChange: (e) => setForm({ ...form, email: e.target.value }),
              className: "w-full bg-slate-900 border border-slate-600 text-white rounded-lg px-4 py-3 focus:outline-none focus:border-indigo-500",
              placeholder: "Enter your email",
              required: true
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
              lineNumber: 78,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
          lineNumber: 76,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-slate-400 text-sm mb-1 block", children: "Password" }, void 0, false, {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
            lineNumber: 88,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: showPassword ? "text" : "password",
                value: form.password,
                onChange: (e) => setForm({ ...form, password: e.target.value }),
                className: "w-full bg-slate-900 border border-slate-600 text-white rounded-lg px-4 py-3 focus:outline-none focus:border-indigo-500",
                placeholder: "••••••••",
                required: true
              },
              void 0,
              false,
              {
                fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
                lineNumber: 90,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => setShowPassword(!showPassword),
                className: "absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200",
                children: showPassword ? "🙈" : "👁️"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
                lineNumber: 98,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
            lineNumber: 89,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
          lineNumber: 87,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-slate-400 text-sm mb-1 block", children: "Organization (Optional)" }, void 0, false, {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
            lineNumber: 108,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              value: form.organization,
              onChange: (e) => setForm({ ...form, organization: e.target.value }),
              className: "w-full bg-slate-900 border border-slate-600 text-white rounded-lg px-4 py-3 focus:outline-none focus:border-indigo-500",
              placeholder: "Add Organization or leave blank for personal use"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
              lineNumber: 109,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
          lineNumber: 107,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-slate-400 text-sm mb-1 block", children: "Role" }, void 0, false, {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
            lineNumber: 118,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              value: form.role,
              onChange: (e) => setForm({ ...form, role: e.target.value }),
              className: "w-full bg-slate-900 border border-slate-600 text-white rounded-lg px-4 py-3 focus:outline-none focus:border-indigo-500",
              children: [
                /* @__PURE__ */ jsxDEV("option", { value: "engineer", children: "Engineer" }, void 0, false, {
                  fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
                  lineNumber: 124,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "admin", children: "Admin" }, void 0, false, {
                  fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
                  lineNumber: 125,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "viewer", children: "Viewer" }, void 0, false, {
                  fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
                  lineNumber: 126,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
              lineNumber: 119,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
          lineNumber: 117,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "submit",
            disabled: loading,
            className: "w-full bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-medium py-3 rounded-lg transition-colors",
            children: loading ? "Creating account..." : "Create Account"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
            lineNumber: 129,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
        lineNumber: 64,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-slate-400 text-sm text-center mt-6", children: [
        "Already have an account?",
        " ",
        /* @__PURE__ */ jsxDEV(Link, { to: "/login", className: "text-indigo-400 hover:text-indigo-300", children: "Sign In" }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
          lineNumber: 140,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
        lineNumber: 138,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
      lineNumber: 55,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
    lineNumber: 49,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx",
    lineNumber: 48,
    columnNumber: 5
  }, this);
};
_s(Register, "6Xnj/nM1xXdqoHKolMNEBlWaoG8=", false, function() {
  return [useNavigate];
});
_c = Register;
export default Register;
var _c;
$RefreshReg$(_c, "Register");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/pages/Register.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0JVOzs7Ozs7Ozs7Ozs7Ozs7OztBQS9CVixTQUFTQSxnQkFBZ0I7QUFDekIsU0FBU0MsTUFBTUMsbUJBQW1CO0FBQ2xDLE9BQU9DLFNBQVM7QUFFaEIsTUFBTUMsV0FBV0EsTUFBTTtBQUFBQyxLQUFBO0FBRXJCLFFBQU0sQ0FBQ0MsTUFBTUMsT0FBTyxJQUFJUCxTQUFTLEVBQUVRLE1BQU0sSUFBSUMsT0FBTyxJQUFJQyxVQUFVLElBQUlDLGNBQWMsSUFBSUMsTUFBTSxXQUFXLENBQUM7QUFDMUcsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUlkLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNlLFNBQVNDLFVBQVUsSUFBSWhCLFNBQVMsS0FBSztBQUM1QyxRQUFNaUIsV0FBV2YsWUFBWTtBQUU3QixRQUFNLENBQUNnQixjQUFjQyxlQUFlLElBQUluQixTQUFTLEtBQUs7QUFFdEQsUUFBTW9CLGVBQWUsT0FBT0MsTUFBTTtBQUNoQ0EsTUFBRUMsZUFBZTtBQUNqQlIsYUFBUyxFQUFFO0FBQ1hFLGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFDRixZQUFNYixJQUFJb0IsS0FBSyxrQkFBa0JqQixJQUFJO0FBQ3JDVyxlQUFTLFFBQVE7QUFBQSxJQUNuQixTQUFTTyxLQUFLO0FBQ1pWLGVBQVNVLElBQUlDLFVBQVVDLE1BQU1DLFdBQVcscUJBQXFCO0FBQUEsSUFDL0QsVUFBQztBQUNDWCxpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsa0VBQ2IsaUNBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLG9CQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLGlDQUFnQywrQkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RDtBQUFBLE1BQzdELHVCQUFDLE9BQUUsV0FBVSx1QkFBc0IsOENBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUU7QUFBQSxTQUZuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSx3REFDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSx5Q0FBd0MsOEJBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0U7QUFBQSxNQUVuRUgsU0FDQyx1QkFBQyxTQUFJLFdBQVUsbUZBQ1pBLG1CQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BR0YsdUJBQUMsVUFBSyxVQUFVTyxjQUFjLFdBQVUsYUFDdEM7QUFBQSwrQkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLHFDQUFvQyx5QkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEQ7QUFBQSxVQUM5RDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsT0FBT2QsS0FBS0U7QUFBQUEsY0FDWixVQUFVLENBQUNhLE1BQU1kLFFBQVEsRUFBRSxHQUFHRCxNQUFNRSxNQUFNYSxFQUFFTyxPQUFPQyxNQUFNLENBQUM7QUFBQSxjQUMxRCxXQUFVO0FBQUEsY0FDVixhQUFZO0FBQUEsY0FDWixVQUFRO0FBQUE7QUFBQSxZQU5WO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1VO0FBQUEsYUFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUNBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUscUNBQW9DLHFCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRDtBQUFBLFVBQzFEO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxPQUFPdkIsS0FBS0c7QUFBQUEsY0FDWixVQUFVLENBQUNZLE1BQU1kLFFBQVEsRUFBRSxHQUFHRCxNQUFNRyxPQUFPWSxFQUFFTyxPQUFPQyxNQUFNLENBQUM7QUFBQSxjQUMzRCxXQUFVO0FBQUEsY0FDVixhQUFZO0FBQUEsY0FDWixVQUFRO0FBQUE7QUFBQSxZQU5WO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1VO0FBQUEsYUFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUNBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUscUNBQW9DLHdCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RDtBQUFBLFVBQzdELHVCQUFDLFNBQUksV0FBVSxZQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFNWCxlQUFlLFNBQVM7QUFBQSxnQkFDOUIsT0FBT1osS0FBS0k7QUFBQUEsZ0JBQ1osVUFBVSxDQUFDVyxNQUFNZCxRQUFRLEVBQUUsR0FBR0QsTUFBTUksVUFBVVcsRUFBRU8sT0FBT0MsTUFBTSxDQUFDO0FBQUEsZ0JBQzlELFdBQVU7QUFBQSxnQkFDVixhQUFZO0FBQUEsZ0JBQ1osVUFBUTtBQUFBO0FBQUEsY0FOVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNVTtBQUFBLFlBRVY7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUyxNQUFNVixnQkFBZ0IsQ0FBQ0QsWUFBWTtBQUFBLGdCQUM1QyxXQUFVO0FBQUEsZ0JBRVRBLHlCQUFlLE9BQU87QUFBQTtBQUFBLGNBTHpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BO0FBQUEsZUFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdCQTtBQUFBLGFBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtQkE7QUFBQSxRQUNBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUscUNBQW9DLHVDQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RTtBQUFBLFVBQzVFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxPQUFPWixLQUFLSztBQUFBQSxjQUNaLFVBQVUsQ0FBQ1UsTUFBTWQsUUFBUSxFQUFFLEdBQUdELE1BQU1LLGNBQWNVLEVBQUVPLE9BQU9DLE1BQU0sQ0FBQztBQUFBLGNBQ2xFLFdBQVU7QUFBQSxjQUNWLGFBQVk7QUFBQTtBQUFBLFlBTGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS2dFO0FBQUEsYUFQbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFDQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLHFDQUFvQyxvQkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUQ7QUFBQSxVQUN6RDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBT3ZCLEtBQUtNO0FBQUFBLGNBQ1osVUFBVSxDQUFDUyxNQUFNZCxRQUFRLEVBQUUsR0FBR0QsTUFBTU0sTUFBTVMsRUFBRU8sT0FBT0MsTUFBTSxDQUFDO0FBQUEsY0FDMUQsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxZQUFPLE9BQU0sWUFBVyx3QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUM7QUFBQSxnQkFDakMsdUJBQUMsWUFBTyxPQUFNLFNBQVEscUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJCO0FBQUEsZ0JBQzNCLHVCQUFDLFlBQU8sT0FBTSxVQUFTLHNCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2QjtBQUFBO0FBQUE7QUFBQSxZQVAvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQTtBQUFBLGFBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsVUFBVWQ7QUFBQUEsWUFDVixXQUFVO0FBQUEsWUFFVEEsb0JBQVUsd0JBQXdCO0FBQUE7QUFBQSxVQUxyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLFdBdkVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3RUE7QUFBQSxNQUVBLHVCQUFDLE9BQUUsV0FBVSwyQ0FBeUM7QUFBQTtBQUFBLFFBQzNCO0FBQUEsUUFDekIsdUJBQUMsUUFBSyxJQUFHLFVBQVMsV0FBVSx5Q0FBdUMsdUJBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsU0F4RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlGQTtBQUFBLE9BL0ZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnR0EsS0FqR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtHQTtBQUVKO0FBQUVWLEdBNUhJRCxVQUFRO0FBQUEsVUFLS0YsV0FBVztBQUFBO0FBQUEsS0FMeEJFO0FBOEhOLGVBQWVBO0FBQVMsSUFBQTBCO0FBQUEsYUFBQUEsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiTGluayIsInVzZU5hdmlnYXRlIiwiYXBpIiwiUmVnaXN0ZXIiLCJfcyIsImZvcm0iLCJzZXRGb3JtIiwibmFtZSIsImVtYWlsIiwicGFzc3dvcmQiLCJvcmdhbml6YXRpb24iLCJyb2xlIiwiZXJyb3IiLCJzZXRFcnJvciIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwibmF2aWdhdGUiLCJzaG93UGFzc3dvcmQiLCJzZXRTaG93UGFzc3dvcmQiLCJoYW5kbGVTdWJtaXQiLCJlIiwicHJldmVudERlZmF1bHQiLCJwb3N0IiwiZXJyIiwicmVzcG9uc2UiLCJkYXRhIiwibWVzc2FnZSIsInRhcmdldCIsInZhbHVlIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUmVnaXN0ZXIuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgTGluaywgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCBhcGkgZnJvbSAnLi4vYXBpL2F4aW9zJztcblxuY29uc3QgUmVnaXN0ZXIgPSAoKSA9PiB7XG4gIC8vIEFkZGVkICdvcmdhbml6YXRpb24nIHRvIGluaXRpYWwgc3RhdGVcbiAgY29uc3QgW2Zvcm0sIHNldEZvcm1dID0gdXNlU3RhdGUoeyBuYW1lOiAnJywgZW1haWw6ICcnLCBwYXNzd29yZDogJycsIG9yZ2FuaXphdGlvbjogJycsIHJvbGU6ICdlbmdpbmVlcicgfSk7XG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcblxuICBjb25zdCBbc2hvd1Bhc3N3b3JkLCBzZXRTaG93UGFzc3dvcmRdID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIHNldEVycm9yKCcnKTtcbiAgICBzZXRMb2FkaW5nKHRydWUpO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBhcGkucG9zdCgnL2F1dGgvcmVnaXN0ZXInLCBmb3JtKTtcbiAgICAgIG5hdmlnYXRlKCcvbG9naW4nKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldEVycm9yKGVyci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCAnUmVnaXN0cmF0aW9uIGZhaWxlZCcpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1zbGF0ZS05MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy1tZFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIG1iLThcIj5cbiAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtd2hpdGVcIj7imqEgT3BzSW5jaWRlbnRBSTwvaDE+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgbXQtMlwiPkFJLVBvd2VyZWQgSW5jaWRlbnQgTWFuYWdlbWVudDwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC04IGJvcmRlciBib3JkZXItc2xhdGUtNzAwXCI+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlIG1iLTZcIj5DcmVhdGUgQWNjb3VudDwvaDI+XG5cbiAgICAgICAgICB7ZXJyb3IgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1yZWQtNTAwLzEwIGJvcmRlciBib3JkZXItcmVkLTUwMC8zMCB0ZXh0LXJlZC00MDAgcm91bmRlZC1sZyBwLTMgbWItNCB0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgIHtlcnJvcn1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCB0ZXh0LXNtIG1iLTEgYmxvY2tcIj5GdWxsIE5hbWU8L2xhYmVsPlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0ubmFtZX1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm0oeyAuLi5mb3JtLCBuYW1lOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNjAwIHRleHQtd2hpdGUgcm91bmRlZC1sZyBweC00IHB5LTMgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwXCJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHlvdXIgZnVsbCBuYW1lXCJcbiAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgdGV4dC1zbSBtYi0xIGJsb2NrXCI+RW1haWw8L2xhYmVsPlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtLmVtYWlsfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybSh7IC4uLmZvcm0sIGVtYWlsOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNjAwIHRleHQtd2hpdGUgcm91bmRlZC1sZyBweC00IHB5LTMgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwXCJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHlvdXIgZW1haWxcIlxuICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCB0ZXh0LXNtIG1iLTEgYmxvY2tcIj5QYXNzd29yZDwvbGFiZWw+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9e3Nob3dQYXNzd29yZCA/IFwidGV4dFwiIDogXCJwYXNzd29yZFwifVxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm0ucGFzc3dvcmR9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm0oeyAuLi5mb3JtLCBwYXNzd29yZDogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNjAwIHRleHQtd2hpdGUgcm91bmRlZC1sZyBweC00IHB5LTMgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwXCJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi4oCi4oCi4oCi4oCi4oCi4oCi4oCi4oCiXCJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dQYXNzd29yZCghc2hvd1Bhc3N3b3JkKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIHJpZ2h0LTMgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtMjAwXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7c2hvd1Bhc3N3b3JkID8gXCLwn5mIXCIgOiBcIvCfkYHvuI9cIn1cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCB0ZXh0LXNtIG1iLTEgYmxvY2tcIj5Pcmdhbml6YXRpb24gKE9wdGlvbmFsKTwvbGFiZWw+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybS5vcmdhbml6YXRpb259XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtKHsgLi4uZm9ybSwgb3JnYW5pemF0aW9uOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNjAwIHRleHQtd2hpdGUgcm91bmRlZC1sZyBweC00IHB5LTMgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwXCJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFkZCBPcmdhbml6YXRpb24gb3IgbGVhdmUgYmxhbmsgZm9yIHBlcnNvbmFsIHVzZVwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCB0ZXh0LXNtIG1iLTEgYmxvY2tcIj5Sb2xlPC9sYWJlbD5cbiAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtLnJvbGV9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtKHsgLi4uZm9ybSwgcm9sZTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTYwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgcHgtNCBweS0zIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItaW5kaWdvLTUwMFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiZW5naW5lZXJcIj5FbmdpbmVlcjwvb3B0aW9uPlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJhZG1pblwiPkFkbWluPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInZpZXdlclwiPlZpZXdlcjwvb3B0aW9uPlxuICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2xvYWRpbmd9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1pbmRpZ28tNjAwIGhvdmVyOmJnLWluZGlnby03MDAgZGlzYWJsZWQ6b3BhY2l0eS01MCB0ZXh0LXdoaXRlIGZvbnQtbWVkaXVtIHB5LTMgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHtsb2FkaW5nID8gJ0NyZWF0aW5nIGFjY291bnQuLi4nIDogJ0NyZWF0ZSBBY2NvdW50J31cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZm9ybT5cblxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIHRleHQtc20gdGV4dC1jZW50ZXIgbXQtNlwiPlxuICAgICAgICAgICAgQWxyZWFkeSBoYXZlIGFuIGFjY291bnQ/eycgJ31cbiAgICAgICAgICAgIDxMaW5rIHRvPVwiL2xvZ2luXCIgY2xhc3NOYW1lPVwidGV4dC1pbmRpZ28tNDAwIGhvdmVyOnRleHQtaW5kaWdvLTMwMFwiPlxuICAgICAgICAgICAgICBTaWduIEluXG4gICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgUmVnaXN0ZXI7XG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FtaXRoIFUgTmF5YWsvLmdlbWluaS9hbnRpZ3Jhdml0eS9zY3JhdGNoL29wc2dlbmllYWkvY2xpZW50L3NyYy9wYWdlcy9SZWdpc3Rlci5qc3gifQ==