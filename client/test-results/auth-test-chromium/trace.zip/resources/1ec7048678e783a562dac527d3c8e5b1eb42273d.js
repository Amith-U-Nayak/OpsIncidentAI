import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AgentStepper.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1aa83cf1"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/AgentStepper.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const AGENTS = [
  { key: "logAnalyzer", label: "Log Analyzer", icon: "🕵️" },
  { key: "rootCauseAnalyzer", label: "Root Cause Analyzer", icon: "🔬" },
  { key: "runbookMatcher", label: "Runbook Matcher", icon: "📗" },
  { key: "postMortemGenerator", label: "Post-Mortem Generator", icon: "📝" }
];
const AgentStepper = ({ events }) => {
  const statusMap = {};
  events.forEach((e) => {
    statusMap[e.agent] = e;
  });
  return /* @__PURE__ */ jsxDEV("div", { className: "bg-slate-800 rounded-xl p-6 border border-slate-700", children: [
    /* @__PURE__ */ jsxDEV("h3", { className: "text-white font-semibold mb-6 flex items-center gap-2", children: "🤖 AI Pipeline Progress" }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/AgentStepper.jsx",
      lineNumber: 40,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: AGENTS.map((agent, index) => {
      const event = statusMap[agent.key];
      const status = event?.status || "pending";
      return /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: `w-10 h-10 rounded-full flex items-center justify-center text-lg flex-shrink-0 border-2 transition-all ${status === "done" ? "bg-green-500/20 border-green-500 text-green-400" : status === "started" ? "bg-indigo-500/20 border-indigo-500 text-indigo-400 animate-pulse" : status === "error" ? "bg-red-500/20 border-red-500 text-red-400" : "bg-slate-700 border-slate-600 text-slate-500"}`, children: status === "done" ? "✓" : status === "error" ? "✗" : agent.icon }, void 0, false, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/AgentStepper.jsx",
          lineNumber: 52,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-white font-medium text-sm", children: agent.label }, void 0, false, {
              fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/AgentStepper.jsx",
              lineNumber: 67,
              columnNumber: 19
            }, this),
            status === "started" && /* @__PURE__ */ jsxDEV("span", { className: "text-xs bg-indigo-500/20 text-indigo-400 px-2 py-0.5 rounded-full animate-pulse", children: "Running..." }, void 0, false, {
              fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/AgentStepper.jsx",
              lineNumber: 69,
              columnNumber: 19
            }, this),
            status === "done" && /* @__PURE__ */ jsxDEV("span", { className: "text-xs bg-green-500/20 text-green-400 px-2 py-0.5 rounded-full", children: "Done" }, void 0, false, {
              fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/AgentStepper.jsx",
              lineNumber: 74,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/AgentStepper.jsx",
            lineNumber: 66,
            columnNumber: 17
          }, this),
          event?.message && /* @__PURE__ */ jsxDEV("p", { className: "text-slate-400 text-xs mt-1", children: event.message }, void 0, false, {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/AgentStepper.jsx",
            lineNumber: 80,
            columnNumber: 17
          }, this),
          status === "done" && event?.data && Object.keys(event.data).length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mt-2 flex flex-wrap gap-2", children: Object.entries(event.data).map(
            ([key, val]) => /* @__PURE__ */ jsxDEV("span", { className: "text-xs bg-slate-700 text-slate-300 px-2 py-1 rounded", children: [
              key,
              ": ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-white font-medium", children: String(val) }, void 0, false, {
                fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/AgentStepper.jsx",
                lineNumber: 87,
                columnNumber: 32
              }, this)
            ] }, key, true, {
              fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/AgentStepper.jsx",
              lineNumber: 86,
              columnNumber: 19
            }, this)
          ) }, void 0, false, {
            fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/AgentStepper.jsx",
            lineNumber: 84,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/AgentStepper.jsx",
          lineNumber: 65,
          columnNumber: 15
        }, this)
      ] }, agent.key, true, {
        fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/AgentStepper.jsx",
        lineNumber: 50,
        columnNumber: 13
      }, this);
    }) }, void 0, false, {
      fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/AgentStepper.jsx",
      lineNumber: 44,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/AgentStepper.jsx",
    lineNumber: 39,
    columnNumber: 5
  }, this);
};
_c = AgentStepper;
export default AgentStepper;
var _c;
$RefreshReg$(_c, "AgentStepper");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/AgentStepper.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Amith U Nayak/.gemini/antigravity/scratch/opsgenieai/client/src/components/AgentStepper.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JNOzs7Ozs7Ozs7Ozs7Ozs7O0FBaEJOLE1BQU1BLFNBQVM7QUFBQSxFQUNiLEVBQUVDLEtBQUssZUFBZUMsT0FBTyxnQkFBZ0JDLE1BQU0sTUFBTTtBQUFBLEVBQ3pELEVBQUVGLEtBQUsscUJBQXFCQyxPQUFPLHVCQUF1QkMsTUFBTSxLQUFLO0FBQUEsRUFDckUsRUFBRUYsS0FBSyxrQkFBa0JDLE9BQU8sbUJBQW1CQyxNQUFNLEtBQUs7QUFBQSxFQUM5RCxFQUFFRixLQUFLLHVCQUF1QkMsT0FBTyx5QkFBeUJDLE1BQU0sS0FBSztBQUFDO0FBRzVFLE1BQU1DLGVBQWVBLENBQUMsRUFBRUMsT0FBTyxNQUFNO0FBRW5DLFFBQU1DLFlBQVksQ0FBQztBQUNuQkQsU0FBT0UsUUFBUSxDQUFDQyxNQUFNO0FBQ3BCRixjQUFVRSxFQUFFQyxLQUFLLElBQUlEO0FBQUFBLEVBQ3ZCLENBQUM7QUFFRCxTQUNFLHVCQUFDLFNBQUksV0FBVSx1REFDYjtBQUFBLDJCQUFDLFFBQUcsV0FBVSx5REFBdUQsdUNBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ1pSLGlCQUFPVSxJQUFJLENBQUNELE9BQU9FLFVBQVU7QUFDNUIsWUFBTUMsUUFBUU4sVUFBVUcsTUFBTVIsR0FBRztBQUNqQyxZQUFNWSxTQUFTRCxPQUFPQyxVQUFVO0FBRWhDLGFBQ0UsdUJBQUMsU0FBb0IsV0FBVSwwQkFFN0I7QUFBQSwrQkFBQyxTQUFJLFdBQVcseUdBQ2RBLFdBQVcsU0FDUCxvREFDQUEsV0FBVyxZQUNYLHFFQUNBQSxXQUFXLFVBQ1gsOENBQ0EsOENBQThDLElBRWpEQSxxQkFBVyxTQUFTLE1BQU1BLFdBQVcsVUFBVSxNQUFNSixNQUFNTixRQVQ5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLG1DQUFDLFVBQUssV0FBVSxrQ0FBa0NNLGdCQUFNUCxTQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RDtBQUFBLFlBQzdEVyxXQUFXLGFBQ1YsdUJBQUMsVUFBSyxXQUFVLG1GQUFpRiwwQkFBakc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBRURBLFdBQVcsVUFDVix1QkFBQyxVQUFLLFdBQVUsbUVBQWlFLG9CQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFWSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBO0FBQUEsVUFDQ0QsT0FBT0UsV0FDTix1QkFBQyxPQUFFLFdBQVUsK0JBQStCRixnQkFBTUUsV0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEQ7QUFBQSxVQUczREQsV0FBVyxVQUFVRCxPQUFPRyxRQUFRQyxPQUFPQyxLQUFLTCxNQUFNRyxJQUFJLEVBQUVHLFNBQVMsS0FDcEUsdUJBQUMsU0FBSSxXQUFVLDZCQUNaRixpQkFBT0csUUFBUVAsTUFBTUcsSUFBSSxFQUFFTDtBQUFBQSxZQUFJLENBQUMsQ0FBQ1QsS0FBS21CLEdBQUcsTUFDeEMsdUJBQUMsVUFBZSxXQUFVLHlEQUN2Qm5CO0FBQUFBO0FBQUFBLGNBQUk7QUFBQSxjQUFFLHVCQUFDLFVBQUssV0FBVSwwQkFBMEJvQixpQkFBT0QsR0FBRyxLQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRDtBQUFBLGlCQURwRG5CLEtBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFVBQ0QsS0FMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsYUF6Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTJCQTtBQUFBLFdBMUNRUSxNQUFNUixLQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkNBO0FBQUEsSUFFSixDQUFDLEtBbkRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvREE7QUFBQSxPQXpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMERBO0FBRUo7QUFBRXFCLEtBcEVJbEI7QUFzRU4sZUFBZUE7QUFBYSxJQUFBa0I7QUFBQSxhQUFBQSxJQUFBIiwibmFtZXMiOlsiQUdFTlRTIiwia2V5IiwibGFiZWwiLCJpY29uIiwiQWdlbnRTdGVwcGVyIiwiZXZlbnRzIiwic3RhdHVzTWFwIiwiZm9yRWFjaCIsImUiLCJhZ2VudCIsIm1hcCIsImluZGV4IiwiZXZlbnQiLCJzdGF0dXMiLCJtZXNzYWdlIiwiZGF0YSIsIk9iamVjdCIsImtleXMiLCJsZW5ndGgiLCJlbnRyaWVzIiwidmFsIiwiU3RyaW5nIiwiX2MiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQWdlbnRTdGVwcGVyLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBBZ2VudFN0ZXBwZXIg4oCUIExpdmUgQUkgcGlwZWxpbmUgcHJvZ3Jlc3MgdHJhY2tlclxuLy8gU2hvd3Mgd2hpY2ggYWdlbnQgaXMgY3VycmVudGx5IHJ1bm5pbmcgYW5kIHdoYXQncyBkb25lXG4vLyBMaXN0ZW5zIHRvIFNvY2tldC5JTyAnYWdlbnRfdXBkYXRlJyBldmVudHMgaW4gcmVhbC10aW1lXG5cbmNvbnN0IEFHRU5UUyA9IFtcbiAgeyBrZXk6ICdsb2dBbmFseXplcicsIGxhYmVsOiAnTG9nIEFuYWx5emVyJywgaWNvbjogJ/CflbXvuI8nIH0sXG4gIHsga2V5OiAncm9vdENhdXNlQW5hbHl6ZXInLCBsYWJlbDogJ1Jvb3QgQ2F1c2UgQW5hbHl6ZXInLCBpY29uOiAn8J+UrCcgfSxcbiAgeyBrZXk6ICdydW5ib29rTWF0Y2hlcicsIGxhYmVsOiAnUnVuYm9vayBNYXRjaGVyJywgaWNvbjogJ/Cfk5cnIH0sXG4gIHsga2V5OiAncG9zdE1vcnRlbUdlbmVyYXRvcicsIGxhYmVsOiAnUG9zdC1Nb3J0ZW0gR2VuZXJhdG9yJywgaWNvbjogJ/Cfk50nIH0sXG5dO1xuXG5jb25zdCBBZ2VudFN0ZXBwZXIgPSAoeyBldmVudHMgfSkgPT4ge1xuICAvLyBCdWlsZCBhIG1hcCBvZiBhZ2VudCDihpIgbGF0ZXN0IHN0YXR1cyBmcm9tIHRoZSBldmVudHMgYXJyYXlcbiAgY29uc3Qgc3RhdHVzTWFwID0ge307XG4gIGV2ZW50cy5mb3JFYWNoKChlKSA9PiB7XG4gICAgc3RhdHVzTWFwW2UuYWdlbnRdID0gZTtcbiAgfSk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTgwMCByb3VuZGVkLXhsIHAtNiBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMFwiPlxuICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgZm9udC1zZW1pYm9sZCBtYi02IGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgIPCfpJYgQUkgUGlwZWxpbmUgUHJvZ3Jlc3NcbiAgICAgIDwvaDM+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgIHtBR0VOVFMubWFwKChhZ2VudCwgaW5kZXgpID0+IHtcbiAgICAgICAgICBjb25zdCBldmVudCA9IHN0YXR1c01hcFthZ2VudC5rZXldO1xuICAgICAgICAgIGNvbnN0IHN0YXR1cyA9IGV2ZW50Py5zdGF0dXMgfHwgJ3BlbmRpbmcnO1xuXG4gICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxkaXYga2V5PXthZ2VudC5rZXl9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgey8qIFN0ZXAgbnVtYmVyIC8gc3RhdHVzIGljb24gKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgdy0xMCBoLTEwIHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LWxnIGZsZXgtc2hyaW5rLTAgYm9yZGVyLTIgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICBzdGF0dXMgPT09ICdkb25lJ1xuICAgICAgICAgICAgICAgICAgPyAnYmctZ3JlZW4tNTAwLzIwIGJvcmRlci1ncmVlbi01MDAgdGV4dC1ncmVlbi00MDAnXG4gICAgICAgICAgICAgICAgICA6IHN0YXR1cyA9PT0gJ3N0YXJ0ZWQnXG4gICAgICAgICAgICAgICAgICA/ICdiZy1pbmRpZ28tNTAwLzIwIGJvcmRlci1pbmRpZ28tNTAwIHRleHQtaW5kaWdvLTQwMCBhbmltYXRlLXB1bHNlJ1xuICAgICAgICAgICAgICAgICAgOiBzdGF0dXMgPT09ICdlcnJvcidcbiAgICAgICAgICAgICAgICAgID8gJ2JnLXJlZC01MDAvMjAgYm9yZGVyLXJlZC01MDAgdGV4dC1yZWQtNDAwJ1xuICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtNzAwIGJvcmRlci1zbGF0ZS02MDAgdGV4dC1zbGF0ZS01MDAnXG4gICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgICB7c3RhdHVzID09PSAnZG9uZScgPyAn4pyTJyA6IHN0YXR1cyA9PT0gJ2Vycm9yJyA/ICfinJcnIDogYWdlbnQuaWNvbn1cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIEFnZW50IGluZm8gKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTBcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIGZvbnQtbWVkaXVtIHRleHQtc21cIj57YWdlbnQubGFiZWx9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAge3N0YXR1cyA9PT0gJ3N0YXJ0ZWQnICYmIChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBiZy1pbmRpZ28tNTAwLzIwIHRleHQtaW5kaWdvLTQwMCBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1wdWxzZVwiPlxuICAgICAgICAgICAgICAgICAgICAgIFJ1bm5pbmcuLi5cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIHtzdGF0dXMgPT09ICdkb25lJyAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgYmctZ3JlZW4tNTAwLzIwIHRleHQtZ3JlZW4tNDAwIHB4LTIgcHktMC41IHJvdW5kZWQtZnVsbFwiPlxuICAgICAgICAgICAgICAgICAgICAgIERvbmVcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICB7ZXZlbnQ/Lm1lc3NhZ2UgJiYgKFxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgdGV4dC14cyBtdC0xXCI+e2V2ZW50Lm1lc3NhZ2V9PC9wPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgey8qIFNob3cgZXh0cmEgZGF0YSBpZiBhdmFpbGFibGUgKi99XG4gICAgICAgICAgICAgICAge3N0YXR1cyA9PT0gJ2RvbmUnICYmIGV2ZW50Py5kYXRhICYmIE9iamVjdC5rZXlzKGV2ZW50LmRhdGEpLmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIGZsZXggZmxleC13cmFwIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIHtPYmplY3QuZW50cmllcyhldmVudC5kYXRhKS5tYXAoKFtrZXksIHZhbF0pID0+IChcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBrZXk9e2tleX0gY2xhc3NOYW1lPVwidGV4dC14cyBiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS0zMDAgcHgtMiBweS0xIHJvdW5kZWRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtrZXl9OiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIGZvbnQtbWVkaXVtXCI+e1N0cmluZyh2YWwpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApO1xuICAgICAgICB9KX1cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgQWdlbnRTdGVwcGVyO1xuIl0sImZpbGUiOiJDOi9Vc2Vycy9BbWl0aCBVIE5heWFrLy5nZW1pbmkvYW50aWdyYXZpdHkvc2NyYXRjaC9vcHNnZW5pZWFpL2NsaWVudC9zcmMvY29tcG9uZW50cy9BZ2VudFN0ZXBwZXIuanN4In0=